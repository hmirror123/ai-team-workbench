import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import assert from 'node:assert/strict';
import {fileURLToPath} from 'node:url';
import {createApp,hashPassword} from '../server.mjs';
const here=path.dirname(fileURLToPath(import.meta.url));
const native=process.env.TEAM_NATIVE_TEST_PACKAGE??path.resolve(here,'../../package.json');
const root=fs.mkdtempSync(path.join(os.tmpdir(),'team-native-run-'));
const data=path.join(root,'data'),home=path.join(root,'dsh-home');
fs.mkdirSync(root,{recursive:true});
const cli=path.join(path.dirname(native),'node_modules/@deepseek-ai/dsh/lib/bin.js');
const q=s=>"'"+s.replace(/'/g,"'\"'\"'")+"'";
const wrapper=path.join(root,'dsh-test.sh');
fs.writeFileSync(wrapper,'#!/bin/sh\nexec '+q(process.execPath)+' '+q(cli)+' "$@"\n',{mode:0o700});
const extraPatch=`- id: agent-default-model\n  config:\n    provider: team-test\n    model: test\n- insert:\n    - id: team-test-adapter\n      name: ${JSON.stringify(path.join(here,'mock-adapter.mjs'))}\n`;
let app;
async function run(phase){
  app=createApp({dataDir:data,config:{password:hashPassword('test-only-password'),wrapper,extraPatch,
    childEnv:{DSH_HOME:home,TEAM_NATIVE_TEST_PACKAGE:native,TEAM_NATIVE_PHASE:phase===1||phase===3?'1':'2'}}});
  await new Promise(r=>app.server.listen(0,'127.0.0.1',r));
  const projectId=phase===3?app.rooms.create('独立的第二项目').id:phase===4?app.rooms.catalog.projects.at(-1).id:'default';
  const room=app.rooms.get(projectId);
  const job=app.enqueue(phase===1||phase===3?'执行首次计算':'继续上一轮，使用原来的工程师会话和角色记忆。',projectId);
  for(let i=0;i<600&&['running','queued'].includes(job.status);i++)await new Promise(r=>setTimeout(r,100));
  if(job.status!=='done'){
    console.log(JSON.stringify(room.state.messages.slice(-12),null,2));
    if(app.getActive())await app.shutdown();throw new Error('Native run failed: '+job.status+'; fixture '+root);
  }
  assert.equal(job.modelPeak,1);assert.ok(room.state.memory.engineer?.length);
  assert.equal(room.jobReview(job.id).status,'done');
  assert.ok(!room.state.messages.some(m=>m.jobId===job.id&&(m.kind==='tool_error'||m.text.includes('提醒未送达'))));
  const ids={root:room.state.rootSession,engineer:room.state.members.engineer.sessionId,reviewer:room.state.members.reviewer.sessionId};
  await app.shutdown();return ids;
}
try{
  const first=await run(1),second=await run(2),third=await run(3),fourth=await run(4);
  assert.deepEqual(first,second,'native root and child sessions must resume unchanged');
  assert.deepEqual(third,fourth,'the second project must resume its own original sessions');
  for(const role of ['root','engineer','reviewer'])assert.notEqual(first[role],third[role],'each project owns distinct native sessions');
  const state=JSON.parse(fs.readFileSync(path.join(data,'state.json'),'utf8'));
  assert.equal(state.memory.engineer[0].revision,2);assert.equal(state.memory.engineer[0].history.length,1);
  assert.ok(state.evidence.some(e=>e.value?.result===44));assert.ok(state.evidence.some(e=>e.value?.result===42));
  assert.equal(state.artifacts.length,2);assert.ok(state.artifacts.every(a=>a.review?.verdict==='approved'));
  assert.equal(state.evidence.filter(e=>e.tool==='evidence_get').length,2);
  console.log('PASS: real rc.4 headless runtime completed four service lifetimes; each project resumed identical root and child Session IDs.');
  console.log('PASS: role memory loaded and corrected across restart; actual calculation receipts preserved; model concurrency peak 1.');
  console.log('PASS: first public mentions created native members; later mentions resumed them; independent read, calculation, evidence lookup and formal review completed in both runs.');
  console.log('PASS: a second isolated project created a separate native team and resumed that same team after another service restart.');
}finally{if(app?.server.listening)await app.shutdown();if(process.env.TEAM_KEEP_TEST)console.log('Fixture: '+root);else fs.rmSync(root,{recursive:true,force:true});}
