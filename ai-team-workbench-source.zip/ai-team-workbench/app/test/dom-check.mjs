// Browser DOM interaction check; uses a deterministic runner, no model requests.
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import vm from 'node:vm';
import {createRequire} from 'node:module';
import assert from 'node:assert/strict';
import {fileURLToPath} from 'node:url';
import {TeamStore} from '../core.mjs';
import {createApp,hashPassword} from '../server.mjs';
const require=createRequire(process.env.TEAM_DOM_TEST_PACKAGE??import.meta.url);
const {JSDOM,VirtualConsole}=require('jsdom');
const root=fs.mkdtempSync(path.join(os.tmpdir(),'team-dom-'));
const here=path.dirname(fileURLToPath(import.meta.url));
const seed=new TeamStore(root);
for(const role of ['lead','engineer','reviewer'])seed.member(role,role+'-default');
seed.state.jobs.push({id:'legacy-job',text:'原有任务：计算并保存报告',status:'done',createdAt:new Date().toISOString()});
seed.append('user','message','原有任务：计算并保存报告',{jobId:'legacy-job'});
const seededCalc=seed.operate({role:'engineer',sessionId:'engineer-default'},'calculate',{expression:'(42+44+46)/3'},'legacy-job');
seed.operate({role:'engineer',sessionId:'engineer-default'},'artifact_create',{title:'原有报告',text:'44',sources:[seededCalc.id]},'legacy-job');
seed.memoryUpdate('engineer',{text:'仅属于原有项目的记忆',sources:[seededCalc.id]},'engineer');
seed.upload('original.txt',Buffer.from('原有资料'));seed.save();
let app;
app=createApp({dataDir:root,config:{password:hashPassword('dom-test-password')},runner:async(job,{store})=>{
  await new Promise(r=>setTimeout(r,40));
  for(const role of ['lead','engineer','reviewer'])if(!store.state.members[role])store.member(role,role+'-'+job.projectId);
  const engineer={role:'engineer',sessionId:store.state.members.engineer.sessionId},reviewer={role:'reviewer',sessionId:store.state.members.reviewer.sessionId};
  const calc=store.operate(engineer,'calculate',{expression:'6*7'},job.id);
  if(job.text==='错误样例'){
    try{store.operate(engineer,'artifact_create',{text:'42',sources:['工具结果 '+calc.id]},job.id);}
    catch(error){store.append('engineer','tool_error','artifact_create：'+error.message,{jobId:job.id,problem:{tool:'artifact_create',message:error.message,targetId:null}});store.save();return {code:1,error:error.message};}
  }
  const artifact=job.resumes?store.state.artifacts.at(-1):store.operate(engineer,'artifact_create',{title:'本项目报告',text:'42',sources:[calc.id]},job.id).value;
  const read=store.operate(reviewer,'artifact_read',{id:artifact.id},job.id);
  store.operate(reviewer,'artifact_review',{id:artifact.id,verdict:'approved',sources:[read.id]},job.id);
  return {code:0,final:'实际工作及正式审核完成'};
}});
await new Promise(r=>app.server.listen(0,'127.0.0.1',r));
const base='http://127.0.0.1:'+app.server.address().port;
let dom;
try{
  let cookie='';const errors=[],sources=[];
  const virtual=new VirtualConsole();virtual.on('jsdomError',error=>errors.push(error.message));
  dom=new JSDOM(fs.readFileSync(path.join(here,'../public/index.html'),'utf8'),{url:base,runScripts:'outside-only',pretendToBeVisual:true,virtualConsole:virtual});
  const window=dom.window,document=window.document,$=id=>document.getElementById(id);
  window.fetch=async(url,options={})=>{const response=await fetch(new URL(url,base),{...options,headers:{cookie,...(options.headers??{})}});const value=response.headers.get('set-cookie');if(value)cookie=value.split(';')[0];return response;};
  window.EventSource=class{constructor(){this.handlers={};sources.push(this);queueMicrotask(()=>this.onopen?.());}addEventListener(name,fn){this.handlers[name]=fn;}close(){this.closed=true;}};
  window.HTMLDialogElement.prototype.showModal=function(){this.open=true;};
  window.HTMLDialogElement.prototype.close=function(){this.open=false;};
  const until=async(condition)=>{for(let i=0;i<200;i++){if(condition())return;await new Promise(r=>setTimeout(r,10));}throw new Error('DOM condition timed out');};
  const submit=form=>form.dispatchEvent(new window.Event('submit',{bubbles:true,cancelable:true}));
  const emit=()=>sources.filter(s=>!s.closed).forEach(s=>s.handlers.change?.());
  const choose=async id=>{$('project-select').value=id;$('project-select').dispatchEvent(new window.Event('change'));await until(()=>$('project-select').value===id&&$('task').placeholder.includes(app.rooms.info(id).name));};
  await vm.runInContext('(async()=>{'+fs.readFileSync(path.join(here,'../public/app.js'),'utf8')+'\n})()',dom.getInternalVMContext());
  assert.ok(!$('login').classList.contains('hidden'));
  $('password').value='dom-test-password';submit($('login-form'));await until(()=>!$('workspace').classList.contains('hidden'));
  assert.equal($('overview-tab').getAttribute('aria-pressed'),'true');assert.ok($('overview-view').textContent.includes('你的指令'));
  assert.equal($('messages').children.length,0,'raw messages remain hidden until requested');
  assert.equal($('jobs-button').textContent,'近期任务');$('jobs-button').click();assert.equal($('panel-title').textContent,'近期任务');
  assert.ok($('panel-body').textContent.includes('继续处理 · 补齐审核'));$('close-panel').click();
  [...$('overview-view').querySelectorAll('button')].find(b=>b.textContent==='继续处理 · 补齐审核').click();
  await until(()=>app.store.state.jobs.length===2&&!app.getActive());emit();await until(()=>$('overview-view').textContent.includes('已续接完成'));
  assert.equal(app.store.state.artifacts.length,1);assert.equal(app.store.state.artifacts[0].review.verdict,'approved');
  $('new-project-button').click();$('project-name').value='第二项目';submit($('project-name').form);
  await until(()=>$('task').placeholder.includes('第二项目'));const second=$('project-select').value;
  assert.notEqual(second,'default');assert.equal($('file-count').textContent,'0');assert.equal($('overview-view').children.length,0);
  $('task').value='B 草稿';await choose('default');$('task').value='A 草稿';await choose(second);assert.equal($('task').value,'B 草稿');await choose('default');assert.equal($('task').value,'A 草稿');await choose(second);
  Object.defineProperty($('file-input'),'files',{configurable:true,value:[new window.File(['B 独立资料'],'second.txt',{type:'text/plain'})]});
  $('file-input').dispatchEvent(new window.Event('change'));await until(()=>$('upload-state').textContent.includes('资料已上传'));
  assert.equal(app.rooms.get(second).state.files[0].name,'second.txt');assert.equal(app.store.state.files[0].name,'original.txt');
  $('task').value='UI-B';submit($('task-form'));await until(()=>app.rooms.get(second).state.jobs.length===1&&!app.getActive());emit();await until(()=>$('overview-view').textContent.includes('本轮结束'));
  $('chat-tab').click();assert.equal($('chat-tab').getAttribute('aria-pressed'),'true');assert.ok($('messages').textContent.includes('你的指令'));assert.ok(!$('messages').textContent.includes('原有任务'));
  $('overview-tab').click();$('task').value='错误样例';submit($('task-form'));await until(()=>app.rooms.get(second).state.jobs.some(j=>j.status==='failed'));emit();await until(()=>$('overview-view').textContent.includes('待核对的报错'));
  $('issues-tab').click();assert.ok($('issues-view').textContent.includes('工程师 · 保存工作产出'));assert.ok($('issues-view').textContent.includes('引用格式错误'));
  assert.ok($('issues-view').textContent.includes('继续处理'));
  assert.ok($('export-button').href.endsWith('project='+second));
  await choose('default');assert.ok($('export-button').href.endsWith('project=default'));assert.ok(!$('files').textContent.includes('second.txt'));
  assert.deepEqual(errors,[]);
  console.log('PASS: live DOM login, visible recent-tasks button, pending-review continuation, organized default view, and raw-chat categories.');
  console.log('PASS: project creation/switching, preserved drafts, scoped upload/export, isolated messages, and visible member/tool error details.');
}finally{dom?.window.close();await app.shutdown();fs.rmSync(root,{recursive:true,force:true});}
