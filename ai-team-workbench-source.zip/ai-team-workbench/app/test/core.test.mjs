import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {TeamStore,calculate,parseTable} from '../core.mjs';
import {createApp,hashPassword} from '../server.mjs';
import {RequestGate} from '../team-plugin.mjs';
import {buildOverview,jobDisplayStatus} from '../overview.mjs';

test('arithmetic parser and quoted CSV preserve actual data',()=>{
  assert.equal(calculate('(42+44+46)/3'),44);assert.equal(calculate('-2^2'),-4);
  assert.equal(calculate('2^-2'),.25);assert.equal(calculate('2^3^2'),512);
  assert.throws(()=>calculate('process.exit()'));assert.throws(()=>calculate('1/0'));
  const table=parseTable('id,note,value\r\nA,"one,two",2\r\nB,"two\nlines",3\r\n');
  assert.equal(table.rows[0].note,'one,two');assert.equal(table.rows[1].note,'two\nlines');
  assert.throws(()=>parseTable('a,a\n1,2'));assert.throws(()=>parseTable('a,b\n1'));
});

test('independent work, artifact review and memory corrections are durable and evidence-based',()=>{
  const dir=fs.mkdtempSync(path.join(os.tmpdir(),'team-core-'));
  try{
    let store=new TeamStore(dir);store.member('lead','root');store.member('engineer','engineer');store.member('reviewer','reviewer');
    const file=store.upload('test.csv',Buffer.from('id,stage,spad,date\nS01,T1,38,2026-11-01\nS02,T2,42,\nS03,T2,44,2026-11-19\nS04,T2,46,2026-11-19\n'));
    const engineer={role:'engineer',sessionId:'engineer'},reviewer={role:'reviewer',sessionId:'reviewer'};
    const stats=store.operate(engineer,'table_stats',{id:file.id,value_column:'spad',where_column:'stage',where_value:'T2'},'job');
    assert.equal(stats.value.groups[0].mean,44);
    const dates=store.operate(reviewer,'table_check',{id:file.id,required_columns:['date'],key_column:'id',where_column:'stage',where_value:'T2'},'job');
    assert.deepEqual(dates.value.missing.date,['S02']);
    const artifact=store.operate(engineer,'artifact_create',{title:'报告',text:'均值44，S02日期缺失。',sources:[stats.id,dates.id]},'job');
    assert.throws(()=>store.operate(reviewer,'artifact_review',{id:artifact.value.id,verdict:'approved',sources:[dates.id]},'job'),/先实际读取/);
    const read=store.operate(reviewer,'artifact_read',{id:artifact.value.id},'job');
    store.operate(reviewer,'artifact_review',{id:artifact.value.id,verdict:'approved',issues:'',sources:[read.id]},'job');
    const note=store.memoryUpdate('reviewer',{text:'审核要实际读产出。',sources:[read.id]},'reviewer');
    assert.throws(()=>store.memoryUpdate('engineer',{id:note.id,expected_revision:1,text:'越界',reason:'x',sources:[read.id]},'engineer'),/不属于/);
    assert.throws(()=>store.memoryUpdate('reviewer',{text:'哈希 5a5efd7f…L',sources:[read.id]},'reviewer'),/不要手抄/);
    store.memoryUpdate('reviewer',{id:note.id,expected_revision:1,text:'审核要读取指定版本的实际产出。',reason:'明确版本',sources:[read.id]},'reviewer');
    assert.throws(()=>store.memoryUpdate('reviewer',{id:note.id,expected_revision:1,text:'过期修改',reason:'x',sources:[read.id]},'reviewer'),/已更新/);
    store=new TeamStore(dir);assert.equal(store.state.memory.reviewer[0].revision,2);assert.equal(store.state.memory.reviewer[0].history.length,1);
    assert.equal(store.state.rootSession,'root');assert.equal(store.state.members.engineer.sessionId,'engineer');
    assert.equal(store.state.artifacts[0].review.verdict,'approved');
    assert.throws(()=>store.operate(engineer,'file_read',{id:'../../secret'},'job'),/不存在/);
  }finally{fs.rmSync(dir,{recursive:true});}
});

test('review completion follows actual receipts, survives old data, and follows revised versions',()=>{
  const dir=fs.mkdtempSync(path.join(os.tmpdir(),'team-review-'));
  try{
    const store=new TeamStore(dir);for(const role of ['lead','engineer','reviewer'])store.member(role,role);
    const engineer={role:'engineer',sessionId:'engineer'},reviewer={role:'reviewer',sessionId:'reviewer'},lead={role:'lead',sessionId:'lead'};
    store.state.jobs.push({id:'old-job',status:'running'});
    const calc=store.operate(engineer,'calculate',{expression:'(42+44+46)/3'},'old-job');
    assert.throws(()=>store.operate(engineer,'artifact_create',{text:'44',sources:['calculate 工具结果 '+calc.id+'：44']},'old-job'),/引用格式错误/);
    const original=store.operate(engineer,'artifact_create',{text:'44',sources:[calc.id]},'old-job').value;
    const fetched=store.operate(reviewer,'evidence_get',{id:calc.id},'old-job');assert.equal(fetched.id,calc.id);
    assert.equal(store.state.messages.at(-1).text,'evidence_get');assert.equal(store.state.evidence.at(-1).value.requestedId,calc.id);
    const read=store.operate(reviewer,'artifact_read',{id:original.id},'old-job');
    assert.throws(()=>store.operate(reviewer,'group_post',{text:'审核通过',kind:'review'},'old-job'),/正式审核/);
    assert.throws(()=>store.operate(lead,'group_post',{text:'全部完成',kind:'decision'},'old-job'),/正式审核/);
    store.state.jobs[0].status='done';delete store.getArtifact(original.id).jobId;store.save();
    const restored=new TeamStore(dir);restored.reconcileReviews();assert.equal(restored.state.jobs[0].status,'needs_review');
    assert.equal(restored.state.members.engineer.sessionId,'engineer');assert.equal(restored.getArtifact(original.id).review,null);
    const count=restored.state.messages.length;restored.reconcileReviews();assert.equal(restored.state.messages.length,count);
    assert.throws(()=>restored.operate(reviewer,'artifact_review',{id:original.id,verdict:'approved',sources:[read.id]},'followup'),/先实际读取/);
    const nextRead=restored.operate(reviewer,'artifact_read',{id:original.id},'followup');
    restored.operate(reviewer,'artifact_review',{id:original.id,verdict:'changes_requested',issues:'补充计算说明',sources:[nextRead.id]},'followup');
    assert.equal(restored.state.jobs[0].status,'needs_changes');
    const revision=restored.operate(engineer,'artifact_create',{text:'(42+44+46)/3 = 44',replaces:original.id,sources:[calc.id]},'followup').value;
    assert.equal(restored.state.jobs[0].status,'needs_review');
    assert.deepEqual(restored.jobReview('old-job').artifactIds,[revision.id]);
    const finalRead=restored.operate(reviewer,'artifact_read',{id:revision.id},'followup');
    restored.operate(reviewer,'artifact_review',{id:revision.id,verdict:'approved',sources:[finalRead.id]},'followup');
    assert.equal(restored.state.jobs[0].status,'done');assert.equal(restored.jobReview('followup').status,'done');
    assert.equal(restored.getArtifact(original.id).review.verdict,'changes_requested');
    assert.equal(restored.state.evidence.find(e=>e.tool==='artifact_create'&&e.value.id===original.id).value.review,null,'creation receipts stay immutable after later reviews');
    fs.writeFileSync(path.join(dir,'artifacts',revision.stored),'changed');
    assert.throws(()=>restored.operate(reviewer,'artifact_read',{id:revision.id},'followup'),/哈希不一致/);
    assert.throws(()=>restored.operate(reviewer,'artifact_review',{id:revision.id,verdict:'approved',sources:[finalRead.id]},'followup'),/内容已经变化/);
  }finally{fs.rmSync(dir,{recursive:true});}
});

test('HTTP exposes pending review, exports evidence IDs, and resumes only unfinished review',async()=>{
  const dir=fs.mkdtempSync(path.join(os.tmpdir(),'team-http-review-'));
  let artifact;
  const app=createApp({dataDir:dir,config:{password:hashPassword('review-test-password')},runner:async(job,{store})=>{
    for(const role of ['lead','engineer','reviewer'])if(!store.state.members[role])store.member(role,role);
    if(!artifact){
      const actor={role:'engineer',sessionId:'engineer'},calc=store.operate(actor,'calculate',{expression:'(42+44+46)/3'},job.id);
      artifact=store.operate(actor,'artifact_create',{title:'report',text:'44',sources:[calc.id]},job.id).value;
      store.operate({role:'reviewer',sessionId:'reviewer'},'group_post',{text:'口头说通过，不应改变正式审核状态'},job.id);
    }else{
      await new Promise(r=>setTimeout(r,35));
      const actor={role:'reviewer',sessionId:'reviewer'},read=store.operate(actor,'artifact_read',{id:artifact.id},job.id);
      store.operate(actor,'artifact_review',{id:artifact.id,verdict:'approved',sources:[read.id]},job.id);
    }
    return {code:0,final:'本轮处理完毕'};
  }});
  await new Promise(r=>app.server.listen(0,'127.0.0.1',r));
  const base='http://127.0.0.1:'+app.server.address().port;
  try{
    const login=await fetch(base+'/api/login',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({password:'review-test-password'})});
    const cookie=login.headers.get('set-cookie').split(';')[0],headers={cookie,'content-type':'application/json'};
    const first=await(await fetch(base+'/api/tasks',{method:'POST',headers,body:JSON.stringify({text:'生成计算报告'})})).json();
    const wait=async()=>{for(let i=0;i<100&&app.store.state.jobs.some(j=>['queued','running'].includes(j.status));i++)await new Promise(r=>setTimeout(r,10));};
    await wait();assert.equal(app.store.state.jobs[0].status,'needs_review');
    assert.ok(!app.store.state.messages.some(m=>m.jobId===first.id&&m.kind==='decision'));
    const exported=await(await fetch(base+'/api/export',{headers:{cookie}})).text();
    assert.ok(exported.includes(app.store.state.evidence[0].id));assert.ok(exported.includes('类型：tool'));
    const resumed=await fetch(base+'/api/resume',{method:'POST',headers,body:JSON.stringify({id:first.id})});assert.equal(resumed.status,200);
    const duplicate=await fetch(base+'/api/resume',{method:'POST',headers,body:JSON.stringify({id:first.id})});assert.equal(duplicate.status,400);
    await wait();assert.ok(app.store.state.jobs.every(j=>j.status==='done'));assert.equal(app.store.state.artifacts.length,1);
    assert.equal(app.store.state.members.engineer.sessionId,'engineer');
  }finally{await app.shutdown();fs.rmSync(dir,{recursive:true});}
});

test('overview identifies the actual failing member and only links evidenced recovery',()=>{
  const dir=fs.mkdtempSync(path.join(os.tmpdir(),'team-overview-'));
  try{
    const store=new TeamStore(dir);for(const role of ['lead','engineer','reviewer'])store.member(role,role);
    const actor={role:'engineer',sessionId:'engineer'};
    store.state.jobs.push({id:'first',text:'计算并保存报告',status:'running',modelCalls:3});
    store.append('user','message','计算并保存报告',{jobId:'first'});
    store.operate({role:'lead',sessionId:'lead'},'group_post',{text:'请执行计算',next:'engineer'},'first');
    const calc=store.operate(actor,'calculate',{expression:'(42+44+46)/3'},'first');
    try{store.operate(actor,'artifact_create',{text:'44',sources:['calculate '+calc.id]},'first');}
    catch(error){store.append('engineer','tool_error','artifact_create：'+error.message,{jobId:'first',problem:{tool:'artifact_create',message:error.message,targetId:null}});}
    const errorId=store.state.messages.at(-1).id;
    store.operate(actor,'group_post',{text:'口头说已解决'},'first');
    let overview=buildOverview(store.state);assert.equal(overview.issues[0].status,'open');assert.equal(overview.issues[0].role,'engineer');
    assert.equal(overview.jobs[0].assignments.find(m=>m.role==='engineer').assignment.text,'请执行计算');
    store.state.jobs[0].status='failed';store.state.jobs[0].followupJobId='second';
    store.state.jobs.push({id:'second',resumes:'first',text:'只补完保存',status:'running'});
    assert.equal(jobDisplayStatus(store.state.jobs[0],store.state.jobs),'resuming');
    const artifact=store.operate(actor,'artifact_create',{text:'44',sources:[calc.id]},'second').value;
    overview=buildOverview(store.state);assert.equal(overview.issues.find(i=>i.id===errorId).status,'recovered');
    assert.match(overview.issues.find(i=>i.id===errorId).recovery.text,/后续任务/);
    try{store.operate(actor,'artifact_read',{id:'artifact_missing'},'second');}
    catch(error){store.append('engineer','tool_error','artifact_read：'+error.message,{jobId:'second',problem:{tool:'artifact_read',message:error.message,targetId:'artifact_missing'}});}
    store.operate(actor,'artifact_read',{id:artifact.id},'second');
    overview=buildOverview(store.state);assert.equal(overview.issues[0].status,'open','reading a different output does not resolve the failed target');
    store.state.jobs[1].status='done';assert.equal(jobDisplayStatus(store.state.jobs[0],store.state.jobs),'recovered');
    assert.equal(store.state.jobs[0].status,'failed','original execution history remains intact');
    assert.equal(store.state.jobs[0].modelCalls,3,'organizing records makes no model requests');
    store.state.jobs.push({id:'older-pending',text:'旧的未完成请求',status:'needs_review'});
    for(let i=0;i<90;i++)store.state.jobs.push({id:'later-'+i,text:'已完成',status:'done'});
    assert.ok(buildOverview(store.state).jobs.some(j=>j.id==='older-pending'),'old unfinished requests remain visible beyond the recent-task window');
  }finally{fs.rmSync(dir,{recursive:true});}
});

test('project rooms isolate context and downloads while a global FIFO keeps concurrency one',async()=>{
  const dir=fs.mkdtempSync(path.join(os.tmpdir(),'team-projects-')),seed=new TeamStore(dir);
  seed.member('lead','existing-root');seed.memoryUpdate('lead',{text:'原有项目专属记忆'});seed.save();
  let releaseFirst;const gate=new Promise(r=>releaseFirst=r);const order=[];let working=0,peak=0;
  const config={password:hashPassword('project-test-password')};
  const app=createApp({dataDir:dir,config,runner:async(job,{store})=>{
    working++;peak=Math.max(peak,working);order.push([job.projectId,job.text]);
    if(job.text==='A-first')await gate;
    for(const role of ['lead','engineer','reviewer'])if(!store.state.members[role])store.member(role,role+'-'+job.projectId);
    const engineer={role:'engineer',sessionId:store.state.members.engineer.sessionId},reviewer={role:'reviewer',sessionId:store.state.members.reviewer.sessionId};
    const calc=store.operate(engineer,'calculate',{expression:'6*7'},job.id);
    const artifact=store.operate(engineer,'artifact_create',{title:job.text,text:'42 '+job.projectId,sources:[calc.id]},job.id).value;
    const read=store.operate(reviewer,'artifact_read',{id:artifact.id},job.id);
    store.operate(reviewer,'artifact_review',{id:artifact.id,verdict:'approved',sources:[read.id]},job.id);
    store.memoryUpdate('engineer',{text:'本项目 '+job.projectId,sources:[calc.id]},'engineer');
    working--;return {code:0,final:'完成 '+job.text};
  }});
  await new Promise(r=>app.server.listen(0,'127.0.0.1',r));const base='http://127.0.0.1:'+app.server.address().port;
  try{
    const login=await fetch(base+'/api/login',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({password:'project-test-password'})});
    const cookie=login.headers.get('set-cookie').split(';')[0];
    const request=(url,value,project='default')=>fetch(base+url,{method:value===undefined?'GET':'POST',headers:{cookie,'content-type':'application/json','x-team-project':project},...(value===undefined?{}:{body:JSON.stringify(value)})});
    const second=await(await request('/api/projects',{name:'B-only'})).json();assert.ok(second.id.startsWith('project_'));
    const empty=await(await request('/api/state',undefined,second.id)).json();assert.equal(empty.rootSession,null);assert.equal(empty.memory.lead.length,0);assert.equal(empty.messages.length,0);
    const uploadA=await(await request('/api/upload',{name:'same.txt',base64:Buffer.from('A-private').toString('base64')})).json();
    const uploadB=await(await request('/api/upload',{name:'same.txt',base64:Buffer.from('B-private').toString('base64')},second.id)).json();
    const first=await(await request('/api/tasks',{text:'A-first'})).json();
    for(let i=0;i<100&&!app.getActive();i++)await new Promise(r=>setTimeout(r,5));
    const b=await(await request('/api/tasks',{text:'B-second'},second.id)).json();
    await request('/api/tasks',{text:'A-third'});
    assert.equal((await request('/api/stop',{},second.id)).status,400);assert.equal(app.getActive().stopRequested,false);
    const active=app.getActive(),internal=(body)=>fetch(base+'/internal',{method:'POST',headers:{authorization:'Bearer '+active.token,'content-type':'application/json'},body:JSON.stringify(body)});
    assert.equal((await internal({action:'snapshot',jobId:b.id})).status,409);
    assert.equal((await internal({action:'calculate',args:{expression:'1+1'},actor:{role:'lead',sessionId:'wrong-project-root'},jobId:first.id})).status,400);
    assert.equal((await request('/api/state',undefined,'../../escape')).status,400);
    releaseFirst();
    for(let i=0;i<300&&[...app.rooms.stores.values()].some(s=>s.state.jobs.some(j=>['queued','running'].includes(j.status)));i++)await new Promise(r=>setTimeout(r,10));
    assert.deepEqual(order,[['default','A-first'],[second.id,'B-second'],['default','A-third']]);assert.equal(peak,1);
    const aState=await(await request('/api/state')).json(),bState=await(await request('/api/state',undefined,second.id)).json();
    assert.equal(aState.rootSession,'existing-root');assert.notEqual(aState.rootSession,bState.rootSession);
    assert.deepEqual(aState.files.map(f=>f.id),[uploadA.id]);assert.deepEqual(bState.files.map(f=>f.id),[uploadB.id]);
    assert.ok(!JSON.stringify(aState.messages).includes('B-second'));assert.ok(!JSON.stringify(bState.messages).includes('A-first'));
    assert.ok(bState.memory.engineer.every(n=>!n.text.includes('default')));assert.equal(bState.memory.lead.length,0);
    const bArtifact=bState.artifacts[0];assert.equal((await request('/api/artifact/'+bArtifact.id)).status,400);
    assert.ok((await(await request('/api/artifact/'+bArtifact.id,undefined,second.id)).json()).text.includes(second.id));
    const exported=await(await fetch(base+'/api/export?project='+second.id,{headers:{cookie}})).text();assert.ok(exported.includes('B-only'));assert.ok(!exported.includes('A-first'));
    const thread=await(await request('/api/messages?job='+first.id)).json();assert.ok(thread.every(m=>m.jobId===first.id));
    const ids={a:aState.rootSession,b:bState.rootSession};await app.shutdown();
    const restarted=createApp({dataDir:dir,config,runner:async()=>{throw new Error('must not replay');}});
    assert.equal(restarted.rooms.get().state.rootSession,ids.a);assert.equal(restarted.rooms.get(second.id).state.rootSession,ids.b);assert.equal(restarted.rooms.list().length,2);restarted.server.close();
  }finally{releaseFirst();if(app.server.listening)await app.shutdown();fs.rmSync(dir,{recursive:true});}
});

test('one request gate serializes entire streams and cancels queued requests safely',async()=>{
  const gate=new RequestGate();let active=0,peak=0;
  const tasks=Array.from({length:6},async()=>{const release=await gate.acquire();active++;peak=Math.max(peak,active);await new Promise(r=>setTimeout(r,8));active--;release();});
  await Promise.all(tasks);assert.equal(peak,1);
  const release=await gate.acquire(),abort=new AbortController(),pending=gate.acquire(abort.signal);abort.abort(new Error('cancelled'));
  await assert.rejects(pending,/cancelled/);release();const again=await gate.acquire();again();
});

test('authenticated HTTP, queue, source boundaries, and interrupted task recovery',async()=>{
  const dir=fs.mkdtempSync(path.join(os.tmpdir(),'team-http-'));
  const order=[];let working=0,peak=0;
  const config={password:hashPassword('test-only-password')};
  const app=createApp({dataDir:dir,config,runner:async job=>{order.push(job.text);working++;peak=Math.max(peak,working);await new Promise(r=>setTimeout(r,35));working--;return {code:0,final:'已处理 '+job.text};}});
  await new Promise(r=>app.server.listen(0,'127.0.0.1',r));
  const base='http://127.0.0.1:'+app.server.address().port;
  try{
    assert.equal((await fetch(base+'/api/state')).status,401);
    const login=await fetch(base+'/api/login',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({password:'test-only-password'})});
    assert.equal(login.status,200);const cookie=login.headers.get('set-cookie').split(';')[0];
    const headers={cookie,'content-type':'application/json'};
    const request=(url,value)=>fetch(base+url,{method:'POST',headers,body:JSON.stringify(value)});
    assert.equal((await fetch(base+'/api/tasks',{method:'POST',headers:{...headers,origin:'https://bad.example'},body:'{"text":"bad"}'})).status,403);
    assert.equal((await request('/api/tasks',{text:'first'})).status,200);
    assert.equal((await request('/api/tasks',{text:'second'})).status,200);
    for(let i=0;i<100&&app.store.state.jobs.some(j=>['queued','running'].includes(j.status));i++)await new Promise(r=>setTimeout(r,10));
    assert.deepEqual(order,['first','second']);assert.equal(peak,1);
    const state=await(await fetch(base+'/api/state',{headers:{cookie}})).json();assert.equal(state.jobs[0].status,'done');
    assert.equal((await request('/api/upload',{name:'x.exe',base64:'YQ=='})).status,400);
    assert.equal((await fetch(base+'/internal',{method:'POST',headers:{'content-type':'application/json'},body:'{}'})).status,401);
    assert.equal((await fetch(base+'/api/export',{headers:{cookie}})).status,200);
    await app.shutdown();
    app.store.state.jobs.push({id:'interrupted-job',status:'running',text:'not replayed'});app.store.save();
    const restarted=createApp({dataDir:dir,config,runner:async()=>{throw new Error('must not replay');}});
    assert.equal(restarted.store.state.jobs.find(j=>j.id==='interrupted-job').status,'interrupted');
    restarted.server.close();
  }finally{if(app.server.listening)await app.shutdown();fs.rmSync(dir,{recursive:true});}
});
