// Native-runtime test fixture. No request leaves this process.
import {createRequire} from 'node:module';
import {randomUUID} from 'node:crypto';
const require=createRequire(process.env.TEAM_NATIVE_TEST_PACKAGE);
const {LlmAdapter}=await import(require.resolve('@deepseek-ai/dsh-llm'));
export const name='team-native-test-model';
export const inject=['llm'];
export function apply(ctx){
  const progress=new Map();
  ctx.llm.registerAdapter(['team-test'],new class extends LlmAdapter{
    async *stream(options){
      const text=JSON.stringify(options.messages);
      const role=/你是固定团队成员 (lead|engineer|researcher|reviewer)/.exec(text)?.[1]??'lead';
      const jobId=process.env.TEAM_JOB_ID,phase=process.env.TEAM_NATIVE_PHASE??'1';
      const p=progress.get(options.sessionId)??{step:0};progress.set(options.sessionId,p);
      const forbidden=(options.tools??[]).filter(t=>['bash','send_message','subagent_fork','subagent'].includes(t.name));
      if(forbidden.length)throw new Error('Unexpected visible tool: '+forbidden.map(x=>x.name).join(','));
      const results=options.messages.filter(m=>m.role==='tool').flatMap(m=>(m.content??[]).filter(b=>b.type==='text').map(b=>{try{return JSON.parse(b.text);}catch{return null;}})).filter(Boolean);
      let call;
      if(role==='engineer'){
        if(p.step===0)call=['memory_get',{}];
        else if(p.step===1){p.note=results.findLast(Array.isArray)?.[0];call=['calculate',{expression:phase==='1'?'(42+44+46)/3':'6*7'}];}
        else if(p.step===2){const receipt=results.findLast(r=>r.tool==='calculate');
          call=p.note?['memory_correct',{id:p.note.id,expected_revision:p.note.revision,text:'已在后续任务重新核实计算流程。',reason:'跨任务续接验证',sources:[receipt.id]}]
            :['memory_add',{text:'计算结论必须有实际工具凭据。',sources:[receipt.id]}];
        }else if(p.step===3){const receipt=results.findLast(r=>r.tool==='calculate');call=['artifact_create',{
          title:'实际计算报告',text:'结果 '+receipt.value.result+'；凭据 '+receipt.id,sources:[receipt.id]}];}
        else if(p.step===4)call=['group_post',{text:'完成工具工作 '+jobId,next:'lead'}];
      }else if(role==='reviewer'){
        if(p.step===0){
          const contents=options.messages.flatMap(m=>typeof m.content==='string'?[m.content]:(m.content??[]).filter(b=>b.type==='text').map(b=>b.text)).join('\n');
          const line=contents.split('\n').findLast(line=>line.startsWith('已保存的产出：'));
          p.artifact=JSON.parse(line.slice('已保存的产出：'.length)).findLast(a=>a.jobId===jobId).id;call=['artifact_read',{id:p.artifact}];
        }else if(p.step===1){const read=results.findLast(r=>r.tool==='artifact_read');call=['evidence_get',{id:read.value.text.match(/ev_[0-9a-f-]+/)[0]}];}
        else if(p.step===2)call=['calculate',{expression:phase==='1'?'(42+44+46)/3':'6*7'}];
        else if(p.step===3){const read=results.findLast(r=>r.tool==='artifact_read'),check=results.findLast(r=>r.tool==='calculate');
          call=['artifact_review',{id:p.artifact,verdict:'approved',issues:'',sources:[read.id,check.id]}];}
        else if(p.step===4)call=['group_post',{text:'审核完成 '+jobId,kind:'review',next:'lead'}];
      }else{
        if(p.step===0)call=['group_post',{text:'请工程师实际计算并保存报告，核实自己的角色记忆。',next:'engineer'}];
        else if(!p.assignedReviewer&&text.includes('完成工具工作 '+jobId)){p.assignedReviewer=true;call=['group_post',{text:'请审核员实际读取报告、独立计算并正式登记审核。',next:'reviewer'}];}
        else if(!p.decided&&text.includes('审核完成 '+jobId)){p.decided=true;call=['group_post',{text:'本轮实际工作及正式审核已完成。',kind:'decision'}];}
        else if(!p.decided)call=['wait_agent',{timeout_ms:10000}];
      }
      p.step++;
      await new Promise(r=>setTimeout(r,12));
      if(call){const id='mock-'+randomUUID(),block={type:'tool-call',id,name:call[0],arguments:JSON.stringify(call[1])};
        yield {type:'block-start',index:0,blockType:'tool-call'};
        yield {type:'tool-call-delta',index:0,id,name:call[0],argumentsDelta:block.arguments};
        yield {type:'block-end',index:0,block};yield {type:'finish',reason:{kind:'tool-calls'}};
      }else{
        yield {type:'block-start',index:0,blockType:'text'};yield {type:'text-delta',index:0,text:'已在群内发言。'};
        yield {type:'block-end',index:0,block:{type:'text',text:'已在群内发言。'}};yield {type:'finish',reason:{kind:'stop'}};
      }
    }
  });
}
