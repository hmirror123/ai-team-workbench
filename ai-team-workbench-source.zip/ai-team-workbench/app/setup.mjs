import fs from 'node:fs';
import path from 'node:path';
import {hashPassword} from './server.mjs';
import {atomicJSON} from './core.mjs';
const [directory,wrapper]=process.argv.slice(2);
if(!directory||!wrapper)throw new Error('Missing install arguments');
const requestedPort = process.env.AI_TEAM_PORT;
const port = requestedPort === undefined ? undefined : Number(requestedPort);
if (port !== undefined && (!Number.isInteger(port) || port < 1024 || port > 65535)) {
  throw new Error('AI_TEAM_PORT 必须是 1024–65535 之间的整数。');
}
fs.mkdirSync(directory,{recursive:true,mode:0o700});fs.mkdirSync(path.join(directory,'work'),{recursive:true,mode:0o700});
const file=path.join(directory,'config.json');
if(fs.existsSync(file)){
  const config=JSON.parse(fs.readFileSync(file,'utf8'));if(!config.password?.hash)throw new Error('现有配置缺少访问口令，请检查后重试。');
  config.wrapper=wrapper;
  if (port !== undefined) config.port=port;
  atomicJSON(file,config);console.log('沿用已有访问口令。');
}else{
  let input='';for await(const chunk of process.stdin)input+=chunk.toString();
  const password=input.replace(/\r?\n$/,'');if(password.length<8||password.length>128)throw new Error('访问口令需为 8–128 字。');
  atomicJSON(file,{version:1,port:port??3358,wrapper,password:hashPassword(password)});console.log('访问口令已保存。');
}
