import fs from 'node:fs';
import path from 'node:path';
import {TeamStore,atomicJSON,uid} from './core.mjs';
import {jobDisplayStatus} from './overview.mjs';

// The original data directory remains the default room, including native sessions.
export class ProjectRooms{
  constructor(directory){
    this.directory=directory;this.catalogFile=path.join(directory,'projects.json');this.stores=new Map();this.onChange=()=>{};
    try{this.catalog=JSON.parse(fs.readFileSync(this.catalogFile,'utf8'));}
    catch(error){if(error.code!=='ENOENT')throw error;this.catalog={version:1,projects:[{id:'default',name:'原有项目',createdAt:new Date().toISOString()}]};}
    if(!Array.isArray(this.catalog.projects)||!this.catalog.projects.some(p=>p.id==='default'))throw new Error('项目目录格式不正确');
    for(const project of this.catalog.projects){
      if(project.id!=='default'&&!/^project_[0-9a-f-]{36}$/.test(project.id))throw new Error('项目标识无效');
      if(this.stores.has(project.id))throw new Error('项目标识重复');
      this.open(project);
    }
    atomicJSON(this.catalogFile,this.catalog);
  }
  open(project){
    const directory=project.id==='default'?this.directory:path.join(this.directory,'projects',project.id);
    const store=new TeamStore(directory);this.stores.set(project.id,store);
    store.onChange=()=>this.onChange();return store;
  }
  get(id='default'){const store=this.stores.get(id);if(!store)throw new Error('项目不存在，请从项目列表选择');return store;}
  info(id='default'){return this.catalog.projects.find(p=>p.id===id);}
  create(name){
    if(typeof name!=='string'||!name.trim()||name.trim().length>48)throw new Error('项目名称需为 1–48 字');
    if(this.catalog.projects.length>=64)throw new Error('最多保留 64 个项目');
    const project={id:uid('project'),name:name.trim(),createdAt:new Date().toISOString()};
    const store=this.open(project);store.save();this.catalog.projects.push(project);atomicJSON(this.catalogFile,this.catalog);this.onChange();return project;
  }
  list(active){return this.catalog.projects.map(project=>{
    const store=this.get(project.id);return {...project,running:active?.projectId===project.id,
      queued:store.state.jobs.filter(j=>j.status==='queued').length,
      pending:store.state.jobs.filter(j=>['needs_review','needs_changes','failed','interrupted','stopped'].includes(jobDisplayStatus(j,store.state.jobs))).length};
  });}
}
