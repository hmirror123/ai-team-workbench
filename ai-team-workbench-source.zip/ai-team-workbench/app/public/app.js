const $=id=>document.getElementById(id);
const el=(tag,cls,text)=>{const n=document.createElement(tag);if(cls)n.className=cls;if(text!==undefined)n.textContent=text;return n;};
const names={user:'你',system:'系统',lead:'总管',researcher:'研究员',engineer:'工程师',reviewer:'审核员'};
const glyphs={user:'你',system:'·',lead:'总',researcher:'研',engineer:'工',reviewer:'审'};
const kinds={proposal:'提案',question:'问题',review:'审核',decision:'结论',handoff:'交接',memory:'角色记忆',notice:'提示',tool_error:'工具提示',note:'补充说明',file:'资料'};
const tools={files_list:'查看资料目录',file_read:'实际阅读资料',calculate:'完成计算',table_check:'检查表格完整性',table_stats:'计算描述统计',evidence_get:'核对实际凭据',artifact_create:'保存工作产出',artifact_read:'读取实际产出',artifact_review:'提交审核结论'};
const statuses={queued:'排队中',running:'正在处理',done:'本轮结束',resuming:'后续任务处理中',recovered:'已续接完成',needs_review:'待正式审核',needs_changes:'审核要求修改',failed:'运行失败',stopped:'已停止',interrupted:'运行中断'};
const resumable=new Set(['failed','stopped','interrupted','needs_review','needs_changes']);
let state,stream,lastSeen=0,messages=new Map(),refreshing=false,pending=false,view='overview',threadJob=null,showRecovered=false,overviewLimit=8;
let selectedProject=localStorage.getItem('ai-team-project')??'default';
const drafts=new Map(),expandedMessages=new Set();
const scopeURL=(url,project=selectedProject)=>url+(url.includes('?')?'&':'?')+'project='+encodeURIComponent(project);
const time=value=>new Intl.DateTimeFormat('zh-CN',{timeZone:'Asia/Shanghai',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',hour12:false}).format(new Date(value));
function banner(text){$('banner').textContent=text;$('banner').classList.toggle('hidden',!text);}
function loginView(){stream?.close();$('workspace').classList.add('hidden');$('login').classList.remove('hidden');}
async function api(url,options={}){
  const response=await fetch(url,{...options,headers:{'x-team-project':selectedProject,...(options.body?{'content-type':'application/json'}:{}),...(options.headers??{})}});
  const value=await response.json();if(!response.ok){if(response.status===401&&!url.endsWith('/login'))loginView();throw new Error(value.error??'请求失败');}return value;
}
const post=(url,value={},project=selectedProject)=>api(url,{method:'POST',body:JSON.stringify(value),headers:{'x-team-project':project}});
const handle=fn=>async(...args)=>{try{await fn(...args);}catch(error){banner(error.message);}};
function showPanel(title){$('panel-title').textContent=title;$('panel-body').replaceChildren();if(!$('panel').open)$('panel').showModal();return $('panel-body');}
function connect(){
  stream?.close();stream=new EventSource('/api/events');
  stream.addEventListener('change',()=>refresh());
  stream.onopen=()=>{$('connection').textContent='已连接';$('connection').classList.remove('off');};
  stream.onerror=()=>{$('connection').textContent='重新连接中';$('connection').classList.add('off');};
}
async function refresh(){
  if(refreshing){pending=true;return;}refreshing=true;
  try{
    const nearBottom=$('chat').scrollHeight-$('chat').scrollTop-$('chat').clientHeight<120;
    const first=!state,project=selectedProject;const next=await api('/api/state'+(lastSeen?'?after='+lastSeen:''));
    if(project!==selectedProject){pending=true;return;}
    state=next;for(const m of next.messages){messages.set(m.id,m);lastSeen=Math.max(lastSeen,m.seq);}
    $('login').classList.add('hidden');$('workspace').classList.remove('hidden');
    renderProjects();renderMembers();renderFiles();renderRun();renderViews();
    $('artifact-count').textContent=state.artifacts.length;
    $('export-button').href=scopeURL('/api/export');
    if(view==='chat'&&(first||nearBottom))$('chat').scrollTop=$('chat').scrollHeight;
  }catch(error){if(!$('workspace').classList.contains('hidden'))banner(error.message);}
  finally{refreshing=false;if(pending){pending=false;setTimeout(refresh,120);}}
}
function renderProjects(){
  const selector=$('project-select'),signature=JSON.stringify(state.projects.map(p=>[p.id,p.name]));
  if(selector.dataset.signature!==signature){selector.replaceChildren();for(const project of state.projects){const option=el('option','',project.name);option.value=project.id;selector.append(option);}selector.dataset.signature=signature;}
  selector.value=state.project.id;
  $('project-hint').textContent='本项目的会话、资料、记忆独立保存';
  $('task').placeholder='给「'+state.project.name+'」发任务，或接着追问…';
}
async function chooseProject(id){
  if(id===selectedProject&&state)return;
  drafts.set(selectedProject,$('task').value);selectedProject=id;localStorage.setItem('ai-team-project',id);
  state=undefined;lastSeen=0;messages.clear();threadJob=null;overviewLimit=8;expandedMessages.clear();
  $('task').value=drafts.get(id)??'';$('upload-state').textContent='';$('panel').close();banner('');
  for(const id of ['overview-view','issues-view','messages'])$(id).replaceChildren();
  await refresh();
}
function changeView(next){view=next;if(next!=='chat')threadJob=null;renderViews();$('chat').scrollTop=0;}
function renderViews(){
  if(!state)return;
  $('overview-view').classList.toggle('hidden',view!=='overview');$('issues-view').classList.toggle('hidden',view!=='issues');$('thread-view').classList.toggle('hidden',view!=='chat');
  for(const name of ['overview','chat','issues']){$(name+'-tab').classList.toggle('active',view===name);$(name+'-tab').setAttribute('aria-pressed',String(view===name));}
  $('issue-count').textContent=(state.overview.openIssues+state.overview.attentionJobs)||'0';
  $('empty').classList.toggle('hidden',state.overview.messageCount>0||state.overview.jobs.length>0||view==='issues');
  if(view==='overview')renderOverview();else if(view==='issues')renderIssues();else renderMessages();
}
const short=(value,max=220)=>value.length>max?value.slice(0,max)+'…':value;
const button=(text,fn,cls='secondary')=>{const b=el('button',cls,text);b.onclick=handle(fn);return b;};
function statusPill(job){return el('span','task-status '+job.status,statuses[job.status]??job.status);}
function resumeButton(job){
  const project=selectedProject;
  return button(job.status==='needs_review'?'继续处理 · 补齐审核':job.status==='needs_changes'?'继续处理 · 按意见修改':'继续处理',async()=>{
    await post('/api/resume',{id:job.id},project);if(project===selectedProject){$('panel').close();banner('已提交后续任务，按顺序处理。');await refresh();}
  },'primary');
}
function followupButton(job){return button('继续追问',()=>{$('panel').close();$('task').value=`继续任务 #${job.number}：${short(job.text,100)}\n\n`;$('task').focus();});}
async function messagePanel(id){const project=selectedProject,full=await api('/api/message/'+encodeURIComponent(id));if(project!==selectedProject)return;const body=showPanel(`#${full.seq} · ${names[full.role]??full.role}`);body.append(el('pre','panel-pre',full.text));if(full.details)body.append(el('pre','panel-pre',(full.evidenceId?'凭据：'+full.evidenceId+'\n':'')+JSON.stringify(full.details,null,2)));}
async function artifactPanel(id){const project=selectedProject,data=await api('/api/artifact/'+id);if(project!==selectedProject)return;const body=showPanel(data.title);body.append(el('pre','panel-pre',data.text));if(data.review?.issues)body.append(el('p','panel-description','审核意见：'+data.review.issues));}
async function viewThread(job){
  const project=selectedProject,data=await api('/api/messages?job='+encodeURIComponent(job.id));if(project!==selectedProject)return;
  for(const m of data)messages.set(m.id,m);$('panel').close();threadJob=job.id;view='chat';renderViews();$('chat').scrollTop=0;
}
function jobCard(job,compact=false){
  const card=el('article','task-card');card.id='task-card-'+job.id;
  const header=el('div','task-card-head');header.append(el('strong','',`任务 #${job.number}`),statusPill(job));card.append(header);
  card.append(el('div','section-label','你的指令'),el('p','instruction',short(job.text,compact?170:330)));
  if(job.text.length>(compact?170:330))card.append(button('查看完整指令',()=>{const body=showPanel('任务 #'+job.number+' · 你的指令');body.append(el('pre','panel-pre',job.text));}));
  if(!compact){
    const statusText={queued:'已进入队列，轮到本项目后开始执行。',running:'成员正在处理，下面显示已记录的实际进展。',resuming:'已有后续任务在处理或排队，等待其完成即可。',recovered:'后续任务已完成，原始过程与报错仍保留可查。',needs_review:'报告已保存，仍需审核员正式登记结论。',needs_changes:'审核提出了修改意见，等待修订和复核。',failed:'运行未正常结束，请查看下方报错或继续处理。',interrupted:'服务重启前运行中断，已有过程和产出保留。',stopped:'已停止，已有过程和产出保留。',done:'本轮运行结束；正式审核状态见各份产出。'};
    card.append(el('p','task-explanation',statusText[job.status]??''));
    if(job.assignments.length){
      card.append(el('div','section-label','成员分工与进展'));const list=el('div','assignment-list');
      for(const member of job.assignments){const row=el('div','assignment-row'),label=el('div','assignment-role');label.append(el('strong','',names[member.role]??member.role),el('span','member-stage '+member.status,member.status==='working'?'处理中':member.status==='assigned'?'已安排':'已参与'));
        const text=el('div','assignment-text',member.assignment?short(member.assignment.text,110):member.latest?short(member.latest.text,110):'参与本轮工作');
        text.append(el('small','',`实际工具 ${member.tools} 次`));row.append(label,text);list.append(row);}card.append(list);
    }
    if(job.decision){const result=el('div','decision-summary');result.append(el('div','section-label','群内结论'),el('p','',job.decision.text),button('查看结论原文',()=>messagePanel(job.decision.id)));card.append(result);}
    if(job.error)card.append(el('p','task-warning','运行异常：'+job.error));
    if(job.artifacts.length){const results=el('div','summary-artifacts');for(const artifact of job.artifacts){const item=button(artifact.title,()=>artifactPanel(artifact.id));item.append(el('span','pill '+artifact.review,artifact.review==='approved'?'已审核':artifact.review==='changes_requested'?'需修改':'待审核'));results.append(item);}card.append(results);}
    const unresolved=job.issues.filter(i=>i.status==='open');if(unresolved.length){const warning=el('div','task-warning');warning.append(el('strong','',`待核对的报错 ${job.openIssues} 条`));for(const issue of unresolved.slice(-2))warning.append(el('p','',`${names[issue.role]??issue.role} · ${tools[issue.tool]??issue.tool??'通知'}：${short(issue.text,180)}`));warning.append(button('查看报错详情',()=>changeView('issues')));card.append(warning);}
  }
  const actions=el('div','task-actions');if(resumable.has(job.status))actions.append(resumeButton(job));else if(['done','recovered'].includes(job.status))actions.append(followupButton(job));
  actions.append(button(`查看本轮记录${compact?'':' · '+job.processCount+' 条'}`,()=>viewThread(job)));
  const summary=el('small','',`实际工具 ${job.toolCount} 次 · 模型调用 ${job.modelCalls} 次`);card.append(actions,summary);return card;
}
function renderOverview(){
  const body=$('overview-view');body.replaceChildren();if(!state.overview.jobs.length)return;
  const head=el('div','overview-head');head.append(el('h3','','任务梳理'),el('p','',`指令、分工、结果分开显示 · 完整群聊 ${state.overview.messageCount} 条保留可查`));body.append(head);
  const priority=j=>j.status==='running'?0:(j.attention||j.openIssues)?1:j.status==='queued'?2:3;
  const jobs=[...state.overview.jobs].sort((a,b)=>priority(a)-priority(b)||b.number-a.number);
  for(const job of jobs.slice(0,overviewLimit))body.append(jobCard(job));
  if(jobs.length>overviewLimit)body.append(button(`查看其余 ${jobs.length-overviewLimit} 个近期任务`,()=>{overviewLimit=40;renderOverview();}));
}
function renderIssues(){
  const body=$('issues-view');body.replaceChildren();const head=el('div','overview-head');head.append(el('h3','','报错与待处理事项'),el('p','','标明出错成员和工具；后续重试成功也会保留原始报错。'));body.append(head);
  const pendingJobs=state.overview.jobs.filter(j=>j.attention);
  for(const job of pendingJobs)body.append(jobCard(job,true));
  const recovered=state.overview.issues.filter(i=>i.status==='recovered');
  if(recovered.length)body.append(button((showRecovered?'收起':'查看')+`重试与参与记录（最近 ${recovered.length} 条）`,()=>{showRecovered=!showRecovered;renderIssues();}));
  const issues=state.overview.issues.filter(i=>showRecovered||i.status==='open');
  if(!issues.length&&!pendingJobs.length)body.append(el('p','all-clear','当前没有待处理的报错或中断任务。'));
  for(const issue of issues){const card=el('article','issue-card '+issue.status),header=el('div','task-card-head');header.append(el('strong','',`${names[issue.role]??issue.role}${issue.targetRole?' → '+names[issue.targetRole]:''} · ${tools[issue.tool]??issue.tool??'通知'}`),el('span','pill '+issue.status,issue.status==='recovered'?'已有后续进展':'待核对'));card.append(header,el('p','',issue.text),el('small','',time(issue.time)));
    if(issue.recovery)card.append(el('p','recovery',issue.recovery.text+' · #'+issue.recovery.seq));
    const actions=el('div','task-actions');actions.append(button('查看报错原文',()=>messagePanel(issue.id)));if(issue.recovery)actions.append(button('查看后续记录',()=>messagePanel(issue.recovery.id)));card.append(actions);body.append(card);}
}
function renderMembers(){
  $('members').replaceChildren();
  for(const [role,info] of Object.entries(state.roles)){
    const button=el('button','member'),avatar=el('span','avatar '+role,glyphs[role]);
    const text=el('span');text.append(el('strong','',info.name),el('small','',(state.members[role]?.status==='working'?'正在处理':'查看角色记忆')+' · '+(state.memory[role]?.length??0)+' 条'));
    const dot=el('span','status-dot'+(state.members[role]?.status==='working'?' busy':''));
    button.append(avatar,text,dot);button.title='查看'+info.name+'的角色记忆';button.onclick=handle(()=>memoryPanel(role));$('members').append(button);
  }
}
function renderFiles(){
  $('file-count').textContent=state.files.length;$('files').replaceChildren();
  if(!state.files.length)$('files').append(el('div','file-item','还没有上传资料'));
  for(const file of [...state.files].reverse()){
    const row=el('div','file-item');row.append(el('span','','▤'));
    const text=el('span','',file.name);text.append(el('small','',Math.max(1,Math.round(file.size/1024))+' KB · 只读'));row.append(text);$('files').append(row);
  }
}
function renderRun(){
  const current=state.jobs.find(j=>j.status==='running'),queued=state.jobs.filter(j=>j.status==='queued').length;
  const interrupted=state.jobs.some(j=>['failed','interrupted','stopped','needs_review','needs_changes'].includes(j.status));
  const other=state.execution.activeProject&&state.execution.activeProject.id!==selectedProject;
  $('run-status').textContent=current?`本项目正在处理 · 已调用 ${current.modelCalls??0} 次`:(other?'正在执行「'+state.execution.activeProject.name+'」':interrupted?'本项目有待处理事项 · 查看近期任务':'团队待命 · 查看近期任务');
  $('run-status').title='点击查看近期任务';$('run-status').style.cursor='pointer';
  $('queue-status').textContent=queued?`本项目 ${queued} 个任务排队 · 全局并发 1`:'全局并发 1 · 各项目按提交顺序执行';
  $('stop-button').classList.toggle('hidden',!current);
}
function renderMessages(){
  const sorted=[...messages.values()].filter(m=>!threadJob||m.jobId===threadJob).sort((a,b)=>a.seq-b.seq);
  $('thread-filter').replaceChildren();if(threadJob){const job=state.overview.jobs.find(j=>j.id===threadJob);$('thread-filter').append(el('span','',`只看任务 #${job?.number??''}`),button('查看全部群聊',()=>{threadJob=null;renderMessages();}));}
  $('older-button').classList.toggle('hidden',Boolean(threadJob)||!sorted.length||sorted[0].seq<=1);$('messages').replaceChildren();
  for(const m of sorted){
    const row=el('article','message '+m.role+' '+m.kind);row.dataset.id=m.id;
    row.append(el('div','avatar '+m.role,glyphs[m.role]??'·'));
    const content=el('div','message-content'),meta=el('div','message-meta');
    const category=m.role==='user'&&m.kind==='message'?'你的指令':m.kind==='tool'?'工作凭据':m.kind==='tool_error'?'执行报错':m.next?(m.role==='lead'?'任务安排':'工作交接'):(kinds[m.kind]??'公开讨论');
    meta.append(el('strong','',names[m.role]??m.role));meta.append(el('span','kind-tag',category));
    const stamp=el('time','',time(m.time));stamp.dateTime=m.time;meta.append(stamp);content.append(meta);
    const collapsed=['tool','memory','note'].includes(m.kind),bubble=el('div',collapsed?'tool-card':'bubble',
      m.kind==='tool'?'✓ '+(tools[m.text]??m.text):m.kind==='note'?'本轮补充说明':m.text);
    if(collapsed||m.hasDetails){
      const button=el('button','detail-button','展开查看');let open=false;
      button.onclick=handle(async()=>{
        if(open){expandedMessages.delete(m.id);bubble.querySelector('.detail-content')?.remove();button.textContent='展开查看';open=false;return;}
        const full=await api('/api/message/'+encodeURIComponent(m.id));
        const text=m.kind==='note'?full.text:(full.evidenceId?'凭据：'+full.evidenceId+'\n\n':'')+JSON.stringify(full.details??full,null,2);
        expandedMessages.add(m.id);bubble.append(el('div','detail-content',text));button.textContent='收起详情';open=true;
      });bubble.append(button);
      if(expandedMessages.has(m.id))button.click();
    }
    if(m.next)bubble.append(el('div','mention','↳ @'+(names[m.next]??m.next)+' 接着处理 · 全员可见'));
    content.append(bubble);
    const actions=el('div','message-tools');
    const quote=el('button','','引用');quote.onclick=()=>{$('task').value=`回复 #${m.seq} ${names[m.role]??m.role}：${m.text.slice(0,160)}\n\n`;$('task').focus();};
    const copy=el('button','','复制');copy.onclick=handle(()=>navigator.clipboard.writeText(m.text));actions.append(quote,copy);
    const job=state.jobs.find(j=>j.id===m.jobId);
    if(m.kind==='notice'&&job&&['failed','stopped','interrupted','needs_review','needs_changes'].includes(job.status)){
      const resume=el('button','','继续处理');resume.onclick=handle(async()=>{await post('/api/resume',{id:job.id});await refresh();});actions.append(resume);
    }
    content.append(actions);row.append(content);$('messages').append(row);
  }
}
async function memoryPanel(role){
  if(!state)return;
  const notes=await api('/api/memory/'+role),body=showPanel(names[role]+' · 角色记忆');
  body.append(el('p','panel-description',state.roles[role].brief+' 记忆更正会写回保存，历史版本保留，更新过程公开显示。'));
  const sid=state.members[role]?.sessionId;body.append(el('p','panel-description',sid?'独立会话：'+sid:'首次需要该成员参与时会建立独立会话。'));
  if(!notes.length)body.append(el('p','panel-description','还没有保存的角色记忆。'));
  for(const note of [...notes].reverse()){
    const item=el('div','panel-item');item.append(el('p','',note.text),el('small','',`版本 ${note.revision} · ${time(note.updatedAt)}`));
    const actions=el('div','actions'),edit=el('button','secondary','更正这条记忆');
    edit.onclick=()=>memoryEditor(role,note);actions.append(edit);
    if(note.history?.length){const history=el('button','secondary','查看旧版');history.onclick=()=>{const area=showPanel(names[role]+' · 更正历史');for(const old of [...note.history].reverse()){const card=el('div','panel-item');card.append(el('small','',`版本 ${old.revision}`),el('p','',old.text));area.append(card);}};actions.append(history);}
    item.append(actions);body.append(item);
  }
  const add=el('button','primary','＋ 添加角色记忆');add.onclick=()=>memoryEditor(role);body.append(add);
}
function memoryEditor(role,note){
  const body=showPanel(names[role]+' · '+(note?'更正记忆':'添加记忆'));
  body.append(el('p','panel-description','写清楚已确认的事实或经验。不要手抄文件哈希；工具依据会单独保留。'));
  const form=el('form'),text=el('textarea','panel-textarea'),reason=el('input','panel-input'),error=el('p','error');
  text.required=true;text.maxLength=1600;text.value=note?.text??'';text.placeholder='这位成员今后应该记住什么？';
  reason.placeholder='说明更正原因';reason.required=Boolean(note);
  const save=el('button','primary','保存并公开更新');save.type='submit';form.append(text);if(note)form.append(reason);form.append(error,save);
  form.onsubmit=async event=>{event.preventDefault();save.disabled=true;try{await post('/api/memory',{role,text:text.value,...(note?{id:note.id,expected_revision:note.revision,reason:reason.value}:{})});await memoryPanel(role);await refresh();}catch(e){error.textContent=e.message;}finally{save.disabled=false;}};
  body.append(form);text.focus();
}
async function artifactsPanel(){
  if(!state)return;
  const body=showPanel('团队工作产出');
  body.append(el('p','panel-description','每个版本独立保存。审核员必须实际读取这一版，才能提交审核结论。'));
  if(!state.artifacts.length)body.append(el('p','panel-description','尚无保存的产出。可以请团队阅读资料后整理报告。'));
  for(const a of [...state.artifacts].reverse()){
    const card=el('div','panel-item');card.append(el('h4','',a.title));
    card.append(el('span','pill '+(a.review?.verdict??''),a.review?.verdict==='approved'?'已审核':a.review?.verdict==='changes_requested'?'需要修改':'待审核'));
    const actions=el('div','actions'),open=el('button','secondary','打开产出'),download=el('a','secondary','下载 Markdown');
    open.onclick=handle(()=>artifactPanel(a.id));
    download.href=scopeURL('/api/artifact/'+a.id+'?download=1');actions.append(open,download);card.append(actions);body.append(card);
  }
}
function jobsPanel(){
  if(!state)return;
  const body=showPanel('近期任务');
  body.append(el('p','panel-description','待审核、要求修改、中断或失败的任务，可直接点击“继续处理”。已结束的任务可继续追问。'));
  for(const job of [...state.overview.jobs].reverse())body.append(jobCard(job,true));
  if(!state.jobs.length)body.append(el('p','panel-description','还没有发起过任务。'));
}
$('login-form').onsubmit=async event=>{
  event.preventDefault();const button=event.currentTarget.querySelector('button');button.disabled=true;$('login-error').textContent='';
  try{await post('/api/login',{password:$('password').value});$('password').value='';await initialize();}catch(error){$('login-error').textContent=error.message;}finally{button.disabled=false;}
};
$('task-form').onsubmit=handle(async event=>{event.preventDefault();const text=$('task').value.trim(),project=selectedProject;if(!text)return;$('send-button').disabled=true;try{await post('/api/tasks',{text},project);drafts.delete(project);if(project===selectedProject){$('task').value='';banner('');await refresh();changeView('overview');}}finally{$('send-button').disabled=false;}});
$('task').onkeydown=event=>{if(event.key==='Enter'&&!event.shiftKey&&!event.isComposing){event.preventDefault();$('task-form').requestSubmit();}};
$('example-button').onclick=()=>{$('task').value='请团队核算 (42+44+46)/3，并说明计算依据。';$('task').focus();};
$('upload-button').onclick=()=>$('file-input').click();
$('file-input').onchange=handle(async()=>{
  const files=[...$('file-input').files],project=selectedProject;try{for(const file of files){if(file.size>8*1024*1024)throw new Error(file.name+' 超过 8 MB');if(project===selectedProject)$('upload-state').textContent='正在上传 '+file.name;
    const data=await new Promise((resolve,reject)=>{const reader=new FileReader();reader.onload=()=>resolve(reader.result.split(',')[1]);reader.onerror=reject;reader.readAsDataURL(file);});
    await post('/api/upload',{name:file.name,base64:data},project);}
    if(project===selectedProject)$('upload-state').textContent=files.length?'资料已上传，可请团队开始分析。':'';await refresh();
  }catch(error){if(project===selectedProject)$('upload-state').textContent='上传未完成，请重试。';throw error;}finally{$('file-input').value='';}
});
$('older-button').onclick=handle(async()=>{const first=Math.min(...[...messages.values()].map(m=>m.seq));const oldHeight=$('chat').scrollHeight;for(const m of await api('/api/messages?before='+first))messages.set(m.id,m);renderMessages();$('chat').scrollTop=$('chat').scrollHeight-oldHeight;});
$('stop-button').onclick=handle(async()=>{await post('/api/stop');await refresh();});
$('run-status').onclick=jobsPanel;
$('jobs-button').onclick=jobsPanel;
$('overview-tab').onclick=()=>changeView('overview');
$('chat-tab').onclick=()=>{threadJob=null;changeView('chat');};
$('issues-tab').onclick=()=>changeView('issues');
$('project-select').onchange=handle(event=>chooseProject(event.target.value));
$('new-project-button').onclick=()=>{
  const body=showPanel('新建项目讨论室');body.append(el('p','panel-description','每个项目单独保存讨论、成员会话、记忆、资料和产出。保留全局并发 1，任务按提交顺序执行。'));
  const form=el('form'),label=el('label','','项目名称'),input=el('input','panel-input'),error=el('p','error'),save=el('button','primary','创建项目');
  input.id='project-name';label.htmlFor=input.id;input.required=true;input.maxLength=48;input.placeholder='例如：论文分析';save.type='submit';form.append(label,input,error,save);
  form.onsubmit=async event=>{event.preventDefault();save.disabled=true;try{const project=await post('/api/projects',{name:input.value});await chooseProject(project.id);changeView('overview');}catch(e){error.textContent=e.message;}finally{save.disabled=false;}};body.append(form);input.focus();
};
$('artifacts-button').onclick=handle(artifactsPanel);
$('sessions-button').onclick=()=>{const body=showPanel('开启新成员会话');body.append(el('p','panel-description','适用于会话无法恢复，或希望重新组织成员时。已有群记录、工作产出和角色记忆会保留，新任务将建立新的独立会话。正在处理或排队时不可操作。'));const button=el('button','primary','保留记忆，开启新成员会话');button.onclick=handle(async()=>{await post('/api/reset-sessions');$('panel').close();await refresh();});body.append(button);};
$('logout-button').onclick=handle(async()=>{await post('/api/logout');loginView();});
$('close-panel').onclick=()=>$('panel').close();
async function initialize(){const projects=await api('/api/projects');if(!projects.some(p=>p.id===selectedProject))selectedProject='default';state=undefined;messages.clear();lastSeen=0;await refresh();connect();}
try{await initialize();}catch{loginView();}
