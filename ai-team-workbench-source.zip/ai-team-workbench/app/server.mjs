import http from 'node:http';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { spawn } from 'node:child_process';
import { randomBytes, scryptSync, timingSafeEqual } from 'node:crypto';
import { ROLES, uid, cleanError } from './core.mjs';
import { ProjectRooms } from './projects.mjs';
import { buildOverview } from './overview.mjs';

const HERE=path.dirname(fileURLToPath(import.meta.url));
export const hashPassword=(password,salt=randomBytes(16).toString('hex'))=>({salt,hash:scryptSync(password,salt,64).toString('hex')});
const json=(res,status,value)=>{res.writeHead(status,{'content-type':'application/json; charset=utf-8','cache-control':'no-store'});res.end(JSON.stringify(value));};
async function body(req,limit=200000){let count=0,parts=[];for await(const data of req){count+=data.length;if(count>limit)throw new Error('请求内容过大');parts.push(data);}return JSON.parse(Buffer.concat(parts).toString()||'{}');}

export function createApp({dataDir,config,runner}={}){
  const rooms=new ProjectRooms(dataDir),store=rooms.get(),sessions=new Map(),events=new Set(),failures=new Map();
  let active=null,closing=false,pumping=false;
  let queueOrder=Math.max(0,...[...rooms.stores.values()].flatMap(s=>s.state.jobs.map(j=>j.queueOrder??0)));
  for(const room of rooms.stores.values()){
    for(const job of room.state.jobs)if(job.status==='running'){job.status='interrupted';room.append('system','notice','上次运行中断，相关记录已保留。可点击“继续处理”。',{jobId:job.id});}
    room.reconcileReviews();for(const member of Object.values(room.state.members))member.status='idle';room.save();
  }
  const server=http.createServer(async(req,res)=>{
    const url=new URL(req.url,'http://localhost');
    res.setHeader('x-content-type-options','nosniff');
    res.setHeader('referrer-policy','same-origin');
    res.setHeader('content-security-policy',"default-src 'self'; connect-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; frame-ancestors 'none'; base-uri 'none'");
    try{
      if(url.pathname==='/internal'){
        if(!active||req.method!=='POST'||req.headers.authorization!=='Bearer '+active.token)return json(res,401,{error:'内部请求未授权'});
        const request=await body(req,150000);
        if(request.jobId!==active.job.id)return json(res,409,{error:'请求轮次不一致'});
        const {action,args={},actor}=request;
        const store=active.store;
        let result;
        if(action==='snapshot')result=null;
        else if(action==='model_start'){
          active.job.modelCalls=args.count;active.job.modelActive=(active.job.modelActive??0)+1;
          active.job.modelPeak=Math.max(active.job.modelPeak??0,active.job.modelActive);store.save();
        }else if(action==='model_end'){active.job.modelActive=Math.max(0,(active.job.modelActive??1)-1);store.save();}
        else if(action==='member'){
          if(actor?.rootId!==actor?.sessionId&&actor?.rootId!==store.state.rootSession)throw new Error('成员不属于当前总管会话');
          store.member(actor.role,actor.sessionId);
        }else{
          if(!actor||store.state.members[actor.role]?.sessionId!==actor.sessionId)throw new Error('未登记的成员');
          if(action==='member_status'){
            store.state.members[actor.role].status=args.status==='working'?'working':'idle';store.save();
          }else if(action==='assistant_text'||action==='notice'){
            if(String(args.text??'').trim())store.append(actor.role,action==='assistant_text'?'note':'notice',String(args.text).slice(0,16000),{jobId:active.job.id,...(args.problem?{problem:args.problem}:{})});store.save();
          }else{
            try{result=store.operate(actor,action,args,active.job.id);}
            catch(error){store.append(actor.role,'tool_error',`${action}：${cleanError(error)}`,{jobId:active.job.id,problem:{tool:action,message:cleanError(error),targetId:typeof args.id==='string'?args.id:null}});store.save();throw error;}
          }
        }
        return json(res,200,{result,state:store.snapshot()});
      }
      if(req.method==='GET'&&['/','/app.js','/style.css','/workbench.css'].includes(url.pathname)){
        const filename=url.pathname==='/'?'index.html':url.pathname.slice(1);
        res.writeHead(200,{'content-type':filename.endsWith('.html')?'text/html; charset=utf-8':filename.endsWith('.css')?'text/css; charset=utf-8':'text/javascript; charset=utf-8'});
        return res.end(fs.readFileSync(path.join(HERE,'public',filename)));
      }
      if(!url.pathname.startsWith('/api/'))return json(res,404,{error:'未找到'});
      if(req.method!=='GET'){
        const origin=req.headers.origin;
        if(origin&&new URL(origin).host!==req.headers.host)return json(res,403,{error:'请求来源不一致，请从群聊页面操作'});
      }
      if(url.pathname==='/api/login'&&req.method==='POST'){
        const ip=req.socket.remoteAddress??'local',now=Date.now(),recent=(failures.get(ip)??[]).filter(t=>now-t<60000);
        if(recent.length>=8)return json(res,429,{error:'尝试较多，请一分钟后重试'});
        const {password}=await body(req,4000);
        if(typeof password!=='string'||password.length>200)throw new Error('口令格式不正确');
        const hash=scryptSync(password,config.password.salt,64),expected=Buffer.from(config.password.hash,'hex');
        if(hash.length!==expected.length||!timingSafeEqual(hash,expected)){recent.push(now);failures.set(ip,recent);return json(res,401,{error:'访问口令不正确'});}
        const token=randomBytes(32).toString('hex');sessions.set(token,now+12*3600000);failures.delete(ip);
        const secure=req.headers['x-forwarded-proto']==='https';
        res.setHeader('set-cookie',`team_session=${token}; HttpOnly; SameSite=Strict; Path=/; Max-Age=43200${secure?'; Secure':''}`);
        return json(res,200,{ok:true});
      }
      const session=/(?:^|;\s*)team_session=([a-f0-9]+)/.exec(req.headers.cookie??'')?.[1];
      if(!session||(sessions.get(session)??0)<Date.now())return json(res,401,{error:'请先输入访问口令'});
      if(url.pathname==='/api/logout'&&req.method==='POST'){sessions.delete(session);res.setHeader('set-cookie','team_session=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0');return json(res,200,{ok:true});}
      if(url.pathname==='/api/projects'){
        if(req.method==='GET')return json(res,200,rooms.list(active));
        if(req.method==='POST'){const {name}=await body(req,4000);return json(res,200,rooms.create(name));}
      }
      const projectId=String(req.headers['x-team-project']??url.searchParams.get('project')??'default');
      const store=rooms.get(projectId);
      if(url.pathname==='/api/state'&&req.method==='GET'){
        const snapshot=store.snapshot();const after=Number(url.searchParams.get('after'))||0;
        if(after)snapshot.messages=store.state.messages.filter(m=>m.seq>after).map(({details,...m})=>({...m,hasDetails:details!==undefined}));
        snapshot.project=rooms.info(projectId);snapshot.projects=rooms.list(active);snapshot.overview=buildOverview(store.state);
        snapshot.execution={concurrency:1,activeProject:active?rooms.info(active.projectId):null,
          queued:[...rooms.stores.values()].reduce((n,s)=>n+s.state.jobs.filter(j=>j.status==='queued').length,0)};
        return json(res,200,snapshot);
      }
      if(url.pathname==='/api/export'&&req.method==='GET'){
        const text='# AI 团队公共讨论记录\n\n项目：'+rooms.info(projectId).name+'\n\n'+store.state.messages.map(m=>
          `## #${m.seq} ${ROLES[m.role]?.name??m.role} · ${new Date(m.time).toLocaleString('zh-CN',{timeZone:'Asia/Shanghai',hour12:false})}\n\n消息 ID：${m.id} · 类型：${m.kind}${m.evidenceId?' · 凭据：'+m.evidenceId:''}\n\n${m.text}\n\n${m.details?'```json\n'+JSON.stringify(m.details,null,2)+'\n```\n':''}`).join('\n');
        res.writeHead(200,{'content-type':'text/markdown; charset=utf-8','content-disposition':'attachment; filename="ai-team-chat.md"'});return res.end(text);
      }
      if(url.pathname==='/api/events'&&req.method==='GET'){
        res.writeHead(200,{'content-type':'text/event-stream','cache-control':'no-cache','connection':'keep-alive','x-accel-buffering':'no'});
        res.write('event: change\ndata: ready\n\n');events.add(res);
        const timer=setInterval(()=>res.write(': keepalive\n\n'),25000);req.on('close',()=>{clearInterval(timer);events.delete(res);});return;
      }
      if(url.pathname==='/api/messages'&&req.method==='GET'){
        const before=Number(url.searchParams.get('before'))||Infinity;
        const jobId=url.searchParams.get('job');
        return json(res,200,store.state.messages.filter(m=>m.seq<before&&(!jobId||m.jobId===jobId)).slice(jobId?-350:-100).map(({details,...m})=>({...m,hasDetails:details!==undefined})));
      }
      if(url.pathname.startsWith('/api/message/')&&req.method==='GET'){
        const id=url.pathname.slice('/api/message/'.length),message=store.state.messages.find(m=>m.id===id);
        return json(res,message?200:404,message??{error:'消息不存在'});
      }
      if(url.pathname==='/api/upload'&&req.method==='POST'){
        const data=await body(req,12*1024*1024);
        if(typeof data.name!=='string'||typeof data.base64!=='string')throw new Error('上传内容不完整');
        return json(res,200,store.upload(data.name,Buffer.from(data.base64,'base64')));
      }
      if(url.pathname==='/api/tasks'&&req.method==='POST'){
        const {text}=await body(req,40000);return json(res,200,enqueue(text,projectId));
      }
      if(url.pathname==='/api/stop'&&req.method==='POST'){if(active){if(active.projectId!==projectId)throw new Error('正在运行的是其他项目，请切换到对应项目再停止');active.stopRequested=true;kill(active.child);store.append('user','notice','已要求停止当前一轮，已有记录保留。',{jobId:active.job.id});store.save();}return json(res,200,{ok:true});}
      if(url.pathname==='/api/resume'&&req.method==='POST'){
        const {id}=await body(req),old=store.state.jobs.find(j=>j.id===id);
        if(!old||!['interrupted','failed','stopped','needs_review','needs_changes'].includes(old.status))throw new Error('这轮无需恢复');
        if(store.state.jobs.some(j=>j.resumes===old.id&&['queued','running'].includes(j.status)))throw new Error('这轮已经有后续任务在处理或排队，请等待结果');
        const next=enqueue(`继续处理此前的请求 ${old.id}。先核对群记录和已有产出，只做未完成部分，避免重复执行。原请求：\n${old.text}`,projectId);
        next.resumes=old.id;old.followupJobId=next.id;store.save();return json(res,200,next);
      }
      if(url.pathname==='/api/reset-sessions'&&req.method==='POST'){
        if(active?.store===store||store.state.jobs.some(j=>j.status==='queued'))throw new Error('请先等待或停止本项目正在处理的请求');
        store.state.archives.push({rootSession:store.state.rootSession,members:store.state.members,time:new Date().toISOString()});
        store.state.rootSession=null;store.state.members={};store.append('user','notice','已开启新成员会话；历史讨论、产出和角色记忆仍可查看。');store.save();return json(res,200,{ok:true});
      }
      if(url.pathname==='/api/memory'&&req.method==='POST'){
        const args=await body(req,20000);return json(res,200,store.memoryUpdate(args.role,args,'user'));
      }
      if(url.pathname.startsWith('/api/artifact/')&&req.method==='GET'){
        const a=store.getArtifact(url.pathname.slice('/api/artifact/'.length));
        const text=fs.readFileSync(path.join(store.dir,'artifacts',a.stored),'utf8');
        if(url.searchParams.has('download')){res.writeHead(200,{'content-type':'text/markdown; charset=utf-8','content-disposition':`attachment; filename="${a.id}.md"`});return res.end(text);}
        return json(res,200,{...a,text});
      }
      if(url.pathname.startsWith('/api/memory/')&&req.method==='GET'){
        const role=url.pathname.slice('/api/memory/'.length);if(!ROLES[role])throw new Error('角色不存在');return json(res,200,store.state.memory[role]??[]);
      }
      return json(res,404,{error:'未找到接口'});
    }catch(error){return json(res,400,{error:cleanError(error)});}
  });
  rooms.onChange=()=>{for(const res of events)res.write('event: change\ndata: updated\n\n');};
  function enqueue(text,projectId='default'){
    const store=rooms.get(projectId);
    if(typeof text!=='string'||!text.trim()||text.length>8000)throw new Error('任务需为 1–8000 字');
    if([...rooms.stores.values()].reduce((n,s)=>n+s.state.jobs.filter(j=>j.status==='queued').length,0)>=12)throw new Error('排队请求较多，请稍后再提交');
    const job={id:uid('job'),projectId,queueOrder:++queueOrder,text:text.trim(),status:'queued',createdAt:new Date().toISOString(),modelCalls:0,modelActive:0,modelPeak:0};
    store.state.jobs.push(job);store.append('user','message',job.text,{jobId:job.id});store.save();setImmediate(pump);return job;
  }
  function kill(child){if(!child?.pid)return;try{process.kill(-child.pid,'SIGTERM');}catch{}const timer=setTimeout(()=>{try{process.kill(-child.pid,'SIGKILL');}catch{}},8000);timer.unref();child.once('close',()=>clearTimeout(timer));}
  async function pump(){
    if(active||closing||pumping)return;pumping=true;
    const next=[...rooms.stores.entries()].flatMap(([projectId,store])=>store.state.jobs.filter(j=>j.status==='queued').map(job=>({projectId,store,job})))
      .sort((a,b)=>(a.job.queueOrder??0)-(b.job.queueOrder??0))[0];
    if(!next){pumping=false;return;}
    const {job,store,projectId}=next;
    job.status='running';job.startedAt=new Date().toISOString();
    active={job,store,projectId,token:randomBytes(32).toString('hex'),child:null,stopRequested:false};store.save();
    try{
      const result=runner?await runner(job,{store,active}):await runDsh(job,active);
      job.status=active.stopRequested?'stopped':result.code===0?'done':'failed';
      if(job.status==='done'){const review=store.jobReview(job.id);job.status=review.status;job.artifactIds=review.artifactIds;}
      if(job.status==='failed'){job.error=cleanError(result.error||'退出码 '+result.code);store.append('system','notice',`这一轮未正常结束：${job.error}`,{jobId:job.id});}
      else if(['needs_review','needs_changes'].includes(job.status))store.reviewNotice(job);
      else if(job.status==='done'&&!store.state.messages.some(m=>m.jobId===job.id&&m.kind==='decision')&&result.final?.trim())
        store.append('lead','decision',result.final.slice(0,8000),{jobId:job.id});
    }catch(error){job.status=active.stopRequested?'stopped':'failed';job.error=cleanError(error);store.append('system','notice','这一轮未正常结束：'+job.error,{jobId:job.id});}
    finally{
      job.endedAt=new Date().toISOString();job.modelActive=0;
      for(const m of Object.values(store.state.members))m.status='idle';active=null;pumping=false;store.save();setImmediate(pump);
    }
  }
  function runDsh(job,current){
    const store=current.store,projectDirectory=store.dir;
    return new Promise((resolve,reject)=>{
      const patch=path.join(projectDirectory,'runtime',job.id+'.yml');
      const rows=`- id: agent-team\n  config:\n    defaultEnabled: true\n    maxTasks: 32\n- id: subagent\n  config:\n    maxDepth: 1\n    maxActiveSubagents: 2\n- insert:\n    - id: public-persistent-team\n      name: ${JSON.stringify(path.join(HERE,'team-plugin.mjs'))}\n`;
      fs.writeFileSync(patch,rows+(config.extraPatch??''),{mode:0o600});
      const args=['--kill-after=10s','300s',config.wrapper,'--profile','headless','--patch',patch,
        '--json','--permission-mode','read-only','--approval-policy','never'];
      if(store.state.rootSession)args.push('--session-id',store.state.rootSession);args.push('-');
      const address=server.address();
      const child=spawn('timeout',args,{cwd:path.join(projectDirectory,'work'),detached:true,
        env:{...process.env,...(config.childEnv??{}),AI_TEAM_DATA:dataDir,
          AI_TEAM_NODE:process.execPath,TEAM_BRIDGE_URL:`http://127.0.0.1:${address.port}`,TEAM_BRIDGE_TOKEN:current.token,TEAM_JOB_ID:job.id},stdio:['pipe','pipe','pipe']});
      current.child=child;let pending='',stderr='',final='';
      child.stdout.on('data',chunk=>{
        pending+=chunk.toString();if(pending.length>1024*1024)pending=pending.slice(-1024*1024);
        const lines=pending.split('\n');pending=lines.pop();
        for(const line of lines){try{const e=JSON.parse(line);
          if(e.type==='session'&&!store.state.rootSession){store.state.rootSession=e.sessionId;store.save();}
          if(e.type==='final')final=e.text??'';
          if(e.type==='error')stderr+=cleanError(e.message??e.error??'模型返回错误')+'\n';
        }catch{}}
      });
      child.stderr.on('data',chunk=>{stderr=(stderr+cleanError(chunk.toString())).slice(-4000);});
      child.on('error',reject);child.on('close',code=>resolve({code,final,error:stderr}));
      const members=Object.keys(store.state.members).filter(r=>r!=='lead');
      child.stdin.end(`当前用户请求编号：${job.id}\n用户请求：\n${job.text}\n\n`
        +`已有固定成员：${members.join('、')||'尚未创建'}。通过 group_post 的 next 公开 @ 固定成员；系统自动创建独立会话或续接原会话，不要自行创建。`
        +'按需召集，先给明确任务，等待实际回应，不必让所有人轮流发言。成员发言和下一步安排都在公共群聊。'
        +'使用已开放的真实资料分析工具；没有资料时不要虚构执行。交付文件先 artifact_create，再公开 @ reviewer；审核员必须 artifact_read 后调用 artifact_review 正式登记。'
        +'总管完成当前请求后在群里给出简洁结论、实际产出及尚未解决的事项；只处理当前编号，不提前执行排队请求。');
    });
  }
  async function shutdown(){closing=true;if(active){active.stopRequested=true;kill(active.child);}for(const e of events)e.end();await new Promise(resolve=>server.close(resolve));}
  server.on('listening',()=>setImmediate(pump));
  return {server,store,rooms,enqueue,shutdown,getActive:()=>active};
}

if(process.argv[1]&&fs.realpathSync(process.argv[1])===fileURLToPath(import.meta.url)){
  const baseDirectory = process.env.XDG_DATA_HOME || path.join(os.homedir(),'.local','share');
  const dataDir = process.env.AI_TEAM_DATA || path.join(baseDirectory,'ai-team-workbench');
  process.umask(0o077);
  process.env.AI_TEAM_DATA = dataDir;
  const config=JSON.parse(fs.readFileSync(path.join(dataDir,'config.json'),'utf8'));
  const app=createApp({dataDir,config});
  app.server.listen(config.port??3358,'127.0.0.1',()=>console.log(`AI 团队群聊已启动：http://127.0.0.1:${app.server.address().port}`));
  for(const sig of ['SIGTERM','SIGINT'])process.on(sig,()=>{app.shutdown().finally(()=>process.exit(0));});
}
