import fs from 'node:fs';
import path from 'node:path';
import { randomUUID, createHash } from 'node:crypto';

export const ROLES = {
  lead: { name: '总管', brief: '明确目标，按需分工，等待真实工作结果，组织公开讨论并交付。不要代写成员结果。简单问答可自己回答，不必召集全员。' },
  researcher: { name: '研究员', brief: '阅读用户提供的资料，区分原文、推断和待确认问题，提供可追溯的依据。' },
  engineer: { name: '工程师', brief: '执行计算和资料检查，形成实际产出。根据具体审核意见修改，不编造执行结果。' },
  reviewer: { name: '审核员', brief: '独立检查来源和实际产出，只提出有证据的缺陷。明确标注的待核验事项不等于错误；没有问题时直接通过。' }
};
export const uid = prefix => prefix+'_'+randomUUID();
export const sha = value => createHash('sha256').update(value).digest('hex');
export const cleanError = value => String(value?.message ?? value).replace(/(?:abk_|sk-)[A-Za-z0-9_-]+/g,'[已隐藏]');
export function atomicJSON(file, value) {
  fs.mkdirSync(path.dirname(file),{recursive:true,mode:0o700});
  const tmp=file+'.'+randomUUID()+'.tmp';
  const fd=fs.openSync(tmp,'wx',0o600);
  try {fs.writeFileSync(fd,JSON.stringify(value,null,2)+'\n');fs.fsyncSync(fd);} finally {fs.closeSync(fd);}
  fs.renameSync(tmp,file);
}
export function parseTable(text, delimiter=',') {
  const rows=[];let row=[],cell='',quoted=false;
  text=text.replace(/^\uFEFF/,'');
  for(let i=0;i<text.length;i++){
    const c=text[i];
    if(quoted){if(c==='"'&&text[i+1]==='"'){cell+='"';i++;}else if(c==='"')quoted=false;else cell+=c;}
    else if(c==='"'&&cell==='')quoted=true;
    else if(c===delimiter){row.push(cell);cell='';}
    else if(c==='\n'){row.push(cell.replace(/\r$/,''));if(row.some(x=>x!==''))rows.push(row);row=[];cell='';}
    else cell+=c;
  }
  if(quoted)throw new Error('表格有未闭合的引号');
  if(cell||row.length){row.push(cell.replace(/\r$/,''));if(row.some(x=>x!==''))rows.push(row);}
  if(!rows.length)throw new Error('表格为空');
  const columns=rows.shift().map(x=>x.trim());
  if(columns.some(x=>!x)||new Set(columns).size!==columns.length)throw new Error('列名不能为空或重复');
  if(rows.length>50000)throw new Error('单次最多分析五万行');
  for(const [i,r] of rows.entries())if(r.length!==columns.length)throw new Error(`第 ${i+2} 行的列数与表头不一致`);
  return {columns,rows:rows.map(r=>Object.fromEntries(columns.map((c,i)=>[c,r[i]])))};
}
// Arithmetic only: a small parser, no eval, shell, filesystem, or arbitrary JavaScript.
export function calculate(input){
  if(typeof input!=='string'||input.length>1000)throw new Error('计算式过长');
  const tokens=input.match(/(?:\d+\.?\d*|\.\d+)(?:[eE][+-]?\d+)?|[()+\-*/^]/g)??[];
  if(tokens.join('')!==input.replace(/\s/g,''))throw new Error('只支持数字、括号和 + - * / ^');
  let i=0;
  const primary=()=>{const t=tokens[i++];if(t==='('){const n=add();if(tokens[i++]!==')')throw new Error('括号不匹配');return n;}if(t===undefined||!Number.isFinite(Number(t)))throw new Error('计算式不完整');return Number(t);};
  const power=()=>{let n=primary();if(tokens[i]==='^'){i++;const p=unary();if(Math.abs(p)>1000)throw new Error('指数过大');n=n**p;}return n;};
  const unary=()=>{if(tokens[i]==='+'){i++;return unary();}if(tokens[i]==='-'){i++;return -unary();}return power();};
  const mul=()=>{let n=unary();while(['*','/'].includes(tokens[i])){const op=tokens[i++],m=unary();n=op==='*'?n*m:n/m;}return n;};
  const add=()=>{let n=mul();while(['+','-'].includes(tokens[i])){const op=tokens[i++],m=mul();n=op==='+'?n+m:n-m;}return n;};
  const result=add();if(i!==tokens.length||!Number.isFinite(result))throw new Error('计算式无效或结果不是有限数值');return result;
}

export class TeamStore {
  constructor(directory){
    this.dir=directory;this.file=path.join(directory,'state.json');
    fs.mkdirSync(directory,{recursive:true,mode:0o700});
    for(const sub of ['uploads','artifacts','runtime','work'])fs.mkdirSync(path.join(directory,sub),{recursive:true,mode:0o700});
    try{this.state=JSON.parse(fs.readFileSync(this.file,'utf8'));}
    catch(e){if(e.code!=='ENOENT')throw e;this.state={version:1,rootSession:null,members:{},messages:[],jobs:[],files:[],artifacts:[],evidence:[],memory:{},archives:[]};}
    this.onChange=()=>{};
  }
  save(){this.state.revision=(this.state.revision??0)+1;atomicJSON(this.file,this.state);this.onChange();}
  append(role,kind,text,extra={}){
    const m={id:uid('msg'),seq:(this.state.messages.at(-1)?.seq??0)+1,time:new Date().toISOString(),role,kind,text,...extra};
    this.state.messages.push(m);return m;
  }
  member(role,sessionId){
    if(!ROLES[role]||typeof sessionId!=='string'||!sessionId)throw new Error('无效的成员身份');
    const old=this.state.members[role];
    if(old?.sessionId&&old.sessionId!==sessionId)throw new Error('成员会话发生变化，请先在界面重建成员会话');
    if(role==='lead'&&this.state.rootSession&&this.state.rootSession!==sessionId)throw new Error('总管会话不一致');
    this.state.members[role]={role,sessionId,status:'working',updatedAt:new Date().toISOString()};
    if(role==='lead')this.state.rootSession=sessionId;
    this.save();
  }
  snapshot(){return {revision:this.state.revision,roles:ROLES,rootSession:this.state.rootSession,members:this.state.members,
    messages:this.state.messages.slice(-180).map(({details,...m})=>({...m,hasDetails:details!==undefined})),messageCount:this.state.messages.length,
    jobs:this.state.jobs.slice(-40),files:this.state.files,artifacts:this.state.artifacts,
    memory:Object.fromEntries(Object.keys(ROLES).map(r=>[r,(this.state.memory[r]??[]).map(n=>({...n,history:undefined}))]))};}
  getFile(id){const f=this.state.files.find(x=>x.id===id);if(!f)throw new Error('资料不存在');return f;}
  getArtifact(id){const a=this.state.artifacts.find(x=>x.id===id);if(!a)throw new Error('产出不存在');return a;}
  readFile(id){const f=this.getFile(id);return {f,text:fs.readFileSync(path.join(this.dir,'uploads',f.stored),'utf8')};}
  upload(name,bytes){
    const ext=path.extname(name).toLowerCase();
    if(!['.txt','.md','.csv','.tsv','.json','.log'].includes(ext))throw new Error('目前支持 TXT、MD、CSV、TSV、JSON、LOG');
    if(bytes.length>8*1024*1024)throw new Error('单个文件最多 8 MB');
    if(bytes.includes(0))throw new Error('请上传 UTF-8 文本资料');
    const id=uid('file'),stored=id+ext;
    fs.writeFileSync(path.join(this.dir,'uploads',stored),bytes,{mode:0o600,flag:'wx'});
    const file={id,name:path.basename(name).slice(0,180),stored,size:bytes.length,sha256:sha(bytes),time:new Date().toISOString()};
    this.state.files.push(file);this.append('user','file',`上传了资料：${file.name}`,{fileId:id});this.save();return file;
  }
  evidence(actor,tool,value,jobId){
    const recorded=structuredClone(value);
    const e={id:uid('ev'),role:actor.role,sessionId:actor.sessionId,tool,value:recorded,jobId,time:new Date().toISOString()};
    this.state.evidence.push(e);this.append(actor.role,'tool',tool,{evidenceId:e.id,details:recorded,jobId});return e;
  }
  refs(ids){
    if(!Array.isArray(ids)||!ids.length||ids.length>12)throw new Error('请引用 1–12 个实际凭据或公开消息 ID');
    return ids.map(id=>{
      if(typeof id!=='string'||!/^(ev|msg)_[0-9a-f-]+$/.test(id))throw new Error('引用格式错误：sources 只能填写原样的 ev_… 或 msg_… ID，不要附加工具名称、说明或计算结果');
      const e=this.state.evidence.find(x=>x.id===id);if(e)return {id,tool:e.tool,role:e.role,
        sha256:e.value?.sha256,summary:JSON.stringify(e.value).slice(0,400)};
      const m=this.state.messages.find(x=>x.id===id);if(m)return {id,role:m.role,text:m.text};
      throw new Error('引用的凭据不存在：'+id);
    });
  }
  jobReview(jobId){
    const ids=new Set(this.state.artifacts.filter(a=>a.jobId===jobId).map(a=>a.id));
    for(const e of this.state.evidence){
      if(e.jobId!==jobId)continue;
      if(e.tool==='artifact_create')ids.add(e.value.id);
      if(e.tool==='artifact_read'||e.tool==='artifact_review')ids.add(e.value.artifactId);
    }
    const replacements=new Map(this.state.artifacts.filter(a=>a.replaces).map(a=>[a.replaces,a.id]));
    const latest=new Set();
    for(let id of ids){const seen=new Set();while(replacements.has(id)&&!seen.has(id)){seen.add(id);id=replacements.get(id);}if(id)latest.add(id);}
    const artifacts=[...latest].map(id=>this.getArtifact(id));
    return {artifactIds:[...latest],status:artifacts.some(a=>a.review?.verdict==='changes_requested')?'needs_changes':
      artifacts.some(a=>a.review?.verdict!=='approved')?'needs_review':'done'};
  }
  reviewNotice(job){
    this.append('system','notice',job.status==='needs_review'?'产出尚未登记正式审核，可点击“继续处理”，由审核员读取后补交审核结论。':
      job.status==='needs_changes'?'产出审核要求修改，可点击“继续处理”，修订后重新审核。':'产出已完成正式审核。',{jobId:job.id});
  }
  reconcileReviews(){
    for(const job of this.state.jobs){
      if(!['done','needs_review','needs_changes'].includes(job.status))continue;
      const review=this.jobReview(job.id);job.artifactIds=review.artifactIds;
      if(job.status!==review.status){job.status=review.status;this.reviewNotice(job);}
    }
  }
  memoryUpdate(role,args,actor='user'){
    if(!ROLES[role])throw new Error('无效角色');
    const text=String(args.text??'').trim();
    if(!text||text.length>1600)throw new Error('记忆正文需为 1–1600 字');
    if(/[a-f0-9]{64}|[a-f0-9]{8,}(?:…|\.{3})[a-z0-9]*/i.test(text))throw new Error('文件哈希请引用凭据，不要手抄到记忆正文');
    const sources=actor==='user'?[]:this.refs(args.sources);
    const notes=this.state.memory[role]??=[];
    let note;
    if(args.id){
      note=notes.find(n=>n.id===args.id);if(!note)throw new Error('这条记忆不属于该角色');
      if(args.expected_revision!==note.revision)throw new Error('记忆已更新，请重新读取后再更正');
      if(!String(args.reason??'').trim())throw new Error('更正时请说明原因');
      note.history.push({revision:note.revision,text:note.text,sources:note.sources,time:note.updatedAt});
      note.revision++;
    }else{if(notes.length>=24)throw new Error('该角色已有 24 条记忆，请更正或合并已有条目');note={id:uid('mem'),revision:1,history:[]};notes.push(note);}
    Object.assign(note,{text,sources,updatedAt:new Date().toISOString()});
    this.append(role,'memory',args.id?'更正了角色记忆':'保存了角色记忆',
      {details:{id:note.id,text,reason:args.reason??'',revision:note.revision,sources,actor}});
    this.save();return note;
  }
  operate(actor,action,args={},jobId){
    if(!ROLES[actor.role]||this.state.members[actor.role]?.sessionId!==actor.sessionId)throw new Error('成员身份未登记');
    let value;
    if(action==='group_post'){
      const text=String(args.text??'').trim();if(!text||text.length>1600)throw new Error('群消息需为 1–1600 字');
      if(args.next&&!ROLES[args.next])throw new Error('接话人不存在');
      if((actor.role==='lead'&&args.kind==='decision')||(actor.role==='reviewer'&&['review','decision'].includes(args.kind))){
        const review=this.jobReview(jobId);
        if(review.status==='needs_review')throw new Error('产出仍待正式审核：审核员须先调用 artifact_read 和 artifact_review，再发表审核或完成结论');
        if(actor.role==='lead'&&review.status==='needs_changes')throw new Error('产出仍需修改：请修订并重新审核，或用 handoff 公开说明未完成事项');
      }
      value=this.append(actor.role,args.kind??'message',text,{next:args.next,jobId});this.save();return value;
    }
    if(action==='group_history')return this.state.messages.filter(m=>!args.before||m.seq<args.before).slice(-Math.min(Math.max(Number(args.limit)||40,1),100));
    if(action==='memory_get')return this.state.memory[actor.role]??[];
    if(action==='memory_add'||action==='memory_correct')return this.memoryUpdate(actor.role,args,actor.role);
    if(action==='evidence_get'){
      value=this.state.evidence.find(e=>e.id===args.id);if(!value)throw new Error('凭据不存在');
      this.evidence(actor,action,{requestedId:value.id,sourceTool:value.tool,sourceRole:value.role,value:value.value},jobId);this.save();return value;
    }
    if(action==='files_list')value=this.state.files.map(({stored,...f})=>f);
    else if(action==='file_read'){
      const {f,text}=this.readFile(args.id),lines=text.split(/\r?\n/),start=Math.max(1,Math.floor(args.start_line)||1),limit=Math.min(300,Math.max(1,Math.floor(args.max_lines)||120));
      value={fileId:f.id,name:f.name,sha256:f.sha256,start_line:start,total_lines:lines.length,
        text:lines.slice(start-1,start-1+limit).join('\n').slice(0,30000)};
    }else if(action==='calculate')value={expression:args.expression,result:calculate(args.expression)};
    else if(action==='table_check'||action==='table_stats'){
      const {f,text}=this.readFile(args.id);const table=parseTable(text,path.extname(f.name).toLowerCase()==='.tsv'?'\t':',');
      let data=table.rows;
      if(args.where_column){if(!table.columns.includes(args.where_column))throw new Error('筛选列不存在');data=data.filter(r=>r[args.where_column]===String(args.where_value??''));}
      if(action==='table_check'){
        const required=args.required_columns?.length?args.required_columns:table.columns;
        const absent=required.filter(c=>!table.columns.includes(c));
        const missing=Object.fromEntries(required.filter(c=>table.columns.includes(c)).map(c=>[c,data.flatMap((r,i)=>r[c].trim()?[]:[args.key_column?r[args.key_column]:i+2])]));
        let duplicates=[];if(args.key_column){if(!table.columns.includes(args.key_column))throw new Error('标识列不存在');const seen=new Set();for(const r of data){const id=r[args.key_column];if(seen.has(id))duplicates.push(id);seen.add(id);}}
        value={fileId:f.id,sha256:f.sha256,columns:table.columns,row_count:data.length,absent_columns:absent,missing,duplicate_ids:[...new Set(duplicates)]};
      }else{
        if(!table.columns.includes(args.value_column))throw new Error('数值列不存在');
        if(args.group_column&&!table.columns.includes(args.group_column))throw new Error('分组列不存在');
        const groups=new Map();for(const r of data){const k=args.group_column?r[args.group_column]:'全部';if(!groups.has(k))groups.set(k,[]);groups.get(k).push(r[args.value_column]);}
        value={fileId:f.id,sha256:f.sha256,value_column:args.value_column,groups:[...groups].map(([group,raw])=>{
          const nums=raw.filter(x=>x.trim()&&Number.isFinite(Number(x))).map(Number),sum=nums.reduce((a,b)=>a+b,0),mean=nums.length?sum/nums.length:null;
          return {group,row_count:raw.length,n:nums.length,missing_or_invalid:raw.length-nums.length,sum,mean,
            min:nums.length?Math.min(...nums):null,max:nums.length?Math.max(...nums):null,
            sample_sd:nums.length>1?Math.sqrt(nums.reduce((a,b)=>a+(b-mean)**2,0)/(nums.length-1)):null};})};
      }
    }else if(action==='artifact_create'){
      if(actor.role==='reviewer')throw new Error('审核员请在群里提出修改意见，由负责成员提交修订');
      const text=String(args.text??'');if(!text.trim()||text.length>80000)throw new Error('产出正文需为 1–80000 字');
      const sources=this.refs(args.sources);const id=uid('artifact'),stored=id+'.md';
      if(args.replaces)this.getArtifact(args.replaces);
      fs.writeFileSync(path.join(this.dir,'artifacts',stored),text,{mode:0o600,flag:'wx'});
      const a={id,title:String(args.title??'工作产出').slice(0,120),stored,role:actor.role,sha256:sha(text),sources,
        replaces:args.replaces??null,review:null,jobId,time:new Date().toISOString()};this.state.artifacts.push(a);value=a;
    }else if(action==='artifact_read'){
      const a=this.getArtifact(args.id),text=fs.readFileSync(path.join(this.dir,'artifacts',a.stored),'utf8');
      if(sha(text)!==a.sha256)throw new Error('产出内容与保存时的哈希不一致，请核对文件后另存修订版');
      value={artifactId:a.id,title:a.title,sha256:a.sha256,text};
    }else if(action==='artifact_review'){
      if(actor.role!=='reviewer')throw new Error('此操作由审核员执行');
      const a=this.getArtifact(args.id);const sources=this.refs(args.sources);
      const read=this.state.evidence.some(e=>e.role==='reviewer'&&e.sessionId===actor.sessionId&&e.jobId===jobId&&
        e.tool==='artifact_read'&&e.value.artifactId===a.id&&e.value.sha256===a.sha256);
      if(!read)throw new Error('请先实际读取这一版产出，再提交审核结论');
      if(sha(fs.readFileSync(path.join(this.dir,'artifacts',a.stored)))!==a.sha256)throw new Error('产出内容已经变化，请核对文件后另存修订版');
      if(!['approved','changes_requested'].includes(args.verdict))throw new Error('审核结论无效');
      if(args.verdict==='changes_requested'&&!String(args.issues??'').trim())throw new Error('要求修改时请写明实际问题');
      a.review={artifactId:a.id,sha256:a.sha256,verdict:args.verdict,issues:String(args.issues??''),sources,
        sessionId:actor.sessionId,jobId,time:new Date().toISOString()};value=a.review;
    }else throw new Error('不支持的工作工具');
    const receipt=this.evidence(actor,action,value,jobId);this.reconcileReviews();this.save();return receipt;
  }
}
