export const name='public-persistent-team';
export const inject=['tools','subagents','agents','systemPrompt','llm'];

export class RequestGate{
  active=false;queue=[];
  acquire(signal){
    if(signal?.aborted)return Promise.reject(signal.reason??new Error('Aborted'));
    return new Promise((resolve,reject)=>{
      const item={resolve,reject,signal};
      item.abort=()=>{const index=this.queue.indexOf(item);if(index>=0)this.queue.splice(index,1);reject(signal.reason??new Error('Aborted'));};
      if(!this.active){this.active=true;resolve(()=>this.release());}
      else {this.queue.push(item);signal?.addEventListener('abort',item.abort,{once:true});}
    });
  }
  release(){
    const item=this.queue.shift();if(!item){this.active=false;return;}
    item.signal?.removeEventListener('abort',item.abort);
    if(item.signal?.aborted){item.reject(item.signal.reason);this.release();return;}
    item.resolve(()=>this.release());
  }
}

export async function apply(ctx){
  const base=process.env.TEAM_BRIDGE_URL,token=process.env.TEAM_BRIDGE_TOKEN,jobId=process.env.TEAM_JOB_ID;
  if(!base||!token||!jobId)throw new Error('请通过团队服务启动此入口');
  let state,toolCalls=0,modelCalls=0;
  const background=new Set(),restricted=new WeakSet(),registered=new Map();
  const bridge=async(action,args={},actor)=>{
    const response=await fetch(base+'/internal',{method:'POST',headers:{'content-type':'application/json',authorization:'Bearer '+token},
      body:JSON.stringify({action,args,actor,jobId}),signal:AbortSignal.timeout(15000)});
    const data=await response.json();if(!response.ok)throw new Error(data.error??'团队服务连接失败');
    if(data.state&&(!state||data.state.revision>=state.revision))state=data.state;return data.result;
  };
  const track=promise=>{background.add(promise);promise.catch(()=>{}).finally(()=>background.delete(promise));};
  const who=agent=>{
    if(!agent)throw new Error('缺少实际成员身份');
    const role=ctx.subagents.namesOf(agent).self;
    if(!['lead','researcher','engineer','reviewer'].includes(role))throw new Error('未知团队成员');
    return {role,sessionId:agent.id,rootId:ctx.subagents.rootOf(agent).id};
  };
  await bridge('snapshot');
  const allRoles=['lead','researcher','engineer','reviewer'];
  const permissions=new Map([['list_agents',allRoles],['wait_agent',allRoles]]);
  const output={schema:{type:'string'},render:(_args,value)=>[{type:'text',text:value}]};
  const field=(properties,required=[])=>({type:'object',properties,required,additionalProperties:false});
  const string={type:'string'},strings={type:'array',items:string},number={type:'number'};
  function register(name,description,parameters,roles=allRoles,execute){
    permissions.set(name,roles);
    ctx.tools.register({name,description,parameters,output,isConcurrencySafe:()=>false,
      async execute(args,exec){
        const actor=who(exec.agent);
        if(!roles.includes(actor.role))throw new Error('此工具没有分配给该角色');
        const result=execute?await execute(args,exec,actor):await bridge(name,args,actor);
        return JSON.stringify(result);
      }},{when:({agent})=>roles.includes(who(agent).role)});
  }
  register('group_post','在全员可见的群里发言。next 公开 @接话人；总管首次 @ 会自动建立其独立会话，以后续接原会话。不要私信。',
    field({text:string,kind:{type:'string',enum:['message','proposal','question','review','decision','handoff']},next:{type:'string',enum:allRoles}},['text']),allRoles,
    async(args,exec,actor)=>{
      if(args.next===actor.role)throw new Error('不要 @自己');
      const post=await bridge('group_post',args,actor);
      if(args.next){
        try{
          const id=await ctx.subagents.resolveName(exec.agent,args.next,exec.signal);
          const prompt=`公共群聊有人 @${args.next}。请阅读全员共享记录，处理当前任务 ${jobId}，并用 group_post 公开回复。\n#${post.seq} ${actor.role}: ${args.text}`;
          if(id===args.next){
            if(actor.role!=='lead')throw new Error('该成员尚未建立独立会话，请总管公开 @ 召集');
            if(state.members[args.next])throw new Error('原成员已登记但原生会话目录未找到，请核对现有会话，不要重复创建');
            const native=ctx.tools.get('subagent');if(!native)throw new Error('原生独立成员启动入口不可用');
            const assignment={name:args.next,description:`公共群任务 #${post.seq}`,prompt};
            await native.execute(assignment,{...exec,name:'subagent',arguments:assignment});
          }else await ctx.subagents.sendMessage(exec.agent,id,[{type:'text',text:prompt}],{signal:exec.signal});
        }catch(error){await bridge('notice',{text:`@${args.next} 提醒未送达：${error.message}。请总管核对成员状态后公开安排。`,
          problem:{tool:'group_post',targetRole:args.next,message:error.message}},actor);return {post,notification:'failed'};}
      }
      return {post,notification:args.next?'accepted':'none'};
    });
  register('group_members','查看固定成员及持久会话。总管用 group_post 的 next 公开 @ 召集，系统自动创建或续接独立成员。',field({}),allRoles,async()=>state.members);
  register('group_history','读取较早的公开群记录。before 为消息序号，不填则读取最近记录。',field({before:number,limit:number}));
  register('files_list','列出用户上传并授权阅读的资料。',field({}));
  register('file_read','实际阅读资料，返回内容、文件哈希及凭据。不能访问任意系统路径。',field({id:string,start_line:number,max_lines:number},['id']));
  register('calculate','实际计算完整数字表达式，支持括号及 + - * / ^。可一次计算的表达式不必拆成多次调用。',field({expression:string},['expression']));
  register('table_check','检查 CSV/TSV 的缺失值、必需列、重复标识；where_column 和 where_value 可按组筛选。',
    field({id:string,required_columns:strings,key_column:string,where_column:string,where_value:string},['id']));
  register('table_stats','实际计算 CSV/TSV 数值列的描述统计，可筛选、分组。空值及非数值不会当成零。',
    field({id:string,value_column:string,group_column:string,where_column:string,where_value:string},['id','value_column']));
  register('evidence_get','读取公开工具凭据的详细结果，核对来源。',field({id:string},['id']));
  register('artifact_create','另存实际 Markdown 产出。sources 只填原样 ev_… 或 msg_… ID，不要附带说明；修订用 replaces 指向旧版，旧版保留。',
    field({title:string,text:string,sources:strings,replaces:string},['title','text','sources']),['lead','researcher','engineer']);
  register('artifact_read','实际打开某一版产出，返回原文及哈希。审核前必须调用。',field({id:string},['id']));
  register('artifact_review','正式登记实际读过的这一版产出的审核结论。必须调用后再公开宣布通过或要求修改；只发群消息不算审核登记。',
    field({id:string,verdict:{type:'string',enum:['approved','changes_requested']},issues:string,sources:strings},['id','verdict','sources']),['reviewer']);
  register('memory_get','读取自己持久保存的经验、依据及更正历史。它与本次会话独立保存。',field({}));
  register('memory_add','保存自己角色的经验或明确事实，引用真实凭据/公开消息。不要把推断当事实，不要手抄文件哈希。',
    field({text:string,sources:strings},['text','sources']));
  register('memory_correct','更正自己的角色记忆并公开原因。必须写回，不能只在群里口头纠正。旧版会保留。',
    field({id:string,expected_revision:number,text:string,reason:string,sources:strings},['id','expected_revision','text','reason','sources']));

  ctx.tools.guard(exec=>{
    const actor=who(exec.agent);toolCalls++;
    let reason;
    if(toolCalls>100)reason='本轮已达到工具调用上限，请总结实际进展。';
    else if(exec.name==='run_code')return;
    else if(!permissions.get(exec.name)?.includes(actor.role))reason=exec.name==='send_message'?'私信已禁用，请在公共群聊回复。':'此入口只开放已授权的资料分析和团队工具。';
    if(reason){track(bridge('notice',{text:`${actor.role} 的 ${exec.name} 调用被拦截：${reason}`,
      problem:{tool:exec.name,message:reason}},actor));return reason;}
  });
  ctx.on('agent/created',({agent})=>{
    if(!restricted.has(agent)){
      const allow=[...permissions].map(([name])=>name)
        .filter(name=>ctx.tools.get(name,agent)!==undefined);
      agent.ctx.tools.restrict({allow});restricted.add(agent);
    }
  });
  ctx.on('system-prompt/assemble',async(assembly,context,next)=>{
    if(context.agent){
      const actor=who(context.agent);
      if(!registered.has(context.agent.id)){await bridge('member',{},actor);registered.set(context.agent.id,actor);}
      else await bridge('snapshot');
    }
    const result=await next();
    return ctx.systemPrompt.refreshContext(result,context);
  });
  ctx.on('session/event',(session,event)=>{
    const actor=registered.get(session.id);if(!actor)return;
    if(event.type==='turn/start'||event.type==='turn/end'){
      track(bridge('member_status',{status:event.type==='turn/start'?'working':'idle'},actor));return;
    }
    if(event.type!=='assistant/message'||event.surfaceOp!=='append')return;
    const text=(event.data?.message?.content??[]).filter(b=>b.type==='text').map(b=>b.text).join('\n').trim();
    if(text)track(bridge('assistant_text',{text:text.slice(0,16000)},actor));
  });
  ctx.on('agent/turn-stopping',async()=>{await Promise.allSettled([...background]);});
  const gate=new RequestGate();
  ctx.on('llm/stream',async function*(options,next){
    const release=await gate.acquire(options.signal);
    try{
      if(++modelCalls>36)throw new Error('本轮已达到模型请求上限');
      await bridge('model_start',{count:modelCalls});
      try{for await(const chunk of next())yield chunk;}
      finally{await bridge('model_end').catch(()=>{});}
    }finally{release();}
  });
  ctx.systemPrompt.context({name:'public-team:state',order:ctx.systemPrompt.getContextOrder('SUBAGENT_DELEGATION')+1,required:true,interpolate:false,
    text:({agent})=>{
      if(!agent)return '';
      const actor=who(agent);
      const role=state.roles[actor.role];
      const messages=state.messages.slice(-110).map(m=>`#${m.seq} ${m.id} ${m.role} [${m.kind}]${m.next?' @'+m.next:''}${m.jobId&&m.jobId!==jobId?' (其他请求)':''}: ${m.text.slice(0,2000)}${m.evidenceId?' 凭据='+m.evidenceId:''}`).join('\n');
      return `你是固定团队成员 ${actor.role}（${role.name}）。${role.brief}\n`
        +'所有发言必须在公共群聊。你自己的会话和角色记忆独立保存；资料分析和产出另存，不修改原始资料。'
        +'不运行任意系统命令、不联网、不读取密钥，不代表用户对外发消息。需要未开放的操作时说明所缺能力。'
        +'工具结果是实际凭据，不编造。面向当前请求按需工作，不把排队的其他请求提前执行。'
        +'讨论用于推进工作、发现真实问题；不强迫反对、反复致谢或全员轮流发言。'
        +'成果先保存为 artifact；审核员必须 artifact_read 实际版本，再 artifact_review 正式登记，然后在群里简短回复。不调用登记工具就仍是待审核。'
        +'sources 只能放原样凭据 ID，不能混入说明。引用格式错误不是瞬时故障；分析失败原因时以真实报错为准，不猜测。'
        +'总管通过 group_post 的 next 公开 @ 固定成员，系统自动创建或续接独立会话。不要直接使用 subagent 或私信。'
        +'子成员公开发言并安排下一位后结束当前轮；总管等待实际回应，避免过早退出。'
        +'普通最终答复最多一句，详细结果发在群里；不复制整段汇报。每轮最多5分钟，请保持讨论简洁。\n'
        +`当前请求：${jobId}\n你的角色记忆：${JSON.stringify((state.memory[actor.role]??[]).slice(-12))}\n`
        +`当前资料：${JSON.stringify(state.files.map(f=>({id:f.id,name:f.name})))}\n`
        +`已保存的产出：${JSON.stringify(state.artifacts.slice(-12).map(a=>({id:a.id,title:a.title,jobId:a.jobId,replaces:a.replaces,review:a.review?.verdict})))}\n`
        +`公开群记录（较早记录用 group_history 获取，工具详情用 evidence_get）：\n${messages}`;
    }});
}
