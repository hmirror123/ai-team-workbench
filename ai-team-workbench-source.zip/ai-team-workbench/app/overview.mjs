const pending=new Set(['needs_review','needs_changes','failed','interrupted','stopped']);
const snippet=(text,max=260)=>String(text??'').slice(0,max);
export function jobDisplayStatus(job,jobs){
  const seen=new Set();let next=job;
  while(next.followupJobId&&!seen.has(next.id)){
    seen.add(next.id);const child=jobs.find(j=>j.id===next.followupJobId);if(!child)break;
    if(['queued','running'].includes(child.status))return 'resuming';
    if(child.status==='done')return 'recovered';next=child;
  }
  return job.status;
}

export function buildOverview(state){
  const byJob=new Map();
  for(const message of state.messages){if(!byJob.has(message.jobId))byJob.set(message.jobId,[]);byJob.get(message.jobId).push(message);}
  const issues=[];
  for(const message of state.messages){
    const delivery=/@(researcher|engineer|reviewer|lead) 提醒未送达/.exec(message.text);
    if(message.kind!=='tool_error'&&!message.problem&&!delivery)continue;
    const problem=message.problem??{};
    const tool=problem.tool??(message.kind==='tool_error'?message.text.split(/[：:]/)[0]:null);
    const targetRole=problem.targetRole??delivery?.[1];
    const descendants=new Set([message.jobId]);
    for(let changed=true;changed;){changed=false;for(const job of state.jobs)if(job.resumes&&descendants.has(job.resumes)&&!descendants.has(job.id)){descendants.add(job.id);changed=true;}}
    const related=state.messages.filter(m=>descendants.has(m.jobId));
    const recovery=related.find(later=>later.seq>message.seq&&(targetRole?
      later.role===targetRole&&['tool','message','review','handoff','decision','note'].includes(later.kind):
      later.kind==='tool'&&later.role===message.role&&later.text===tool&&(!problem.targetId||
        [later.details?.artifactId,later.details?.fileId,later.details?.id].includes(problem.targetId))));
    issues.push({id:message.id,seq:message.seq,jobId:message.jobId,role:message.role,tool,targetRole,
      text:snippet(problem.message??message.text,700),time:message.time,
      status:recovery?'recovered':'open',recovery:recovery?{id:recovery.id,seq:recovery.seq,evidenceId:recovery.evidenceId,
        text:targetRole?'成员后来已参与':recovery.jobId===message.jobId?'随后同一工具调用成功':'后续任务中同一工具调用成功'}:null});
  }
  const recent=new Set(state.jobs.slice(-40).map(j=>j.id));
  const jobs=state.jobs.filter(j=>recent.has(j.id)||pending.has(jobDisplayStatus(j,state.jobs))).map(job=>{
    const messages=byJob.get(job.id)??[],tools=messages.filter(m=>m.kind==='tool');
    const jobIssues=issues.filter(i=>i.jobId===job.id);
    const roles=new Set([...Object.keys(state.members),...messages.map(m=>m.next).filter(Boolean)]);
    const assignments=[...roles].map(role=>{
      const member=state.members[role];
      const assignment=messages.findLast(m=>m.next===role);
      const work=messages.filter(m=>m.role===role&&m.kind!=='notice');
      if(!assignment&&!work.length)return null;
      const latest=work.findLast(m=>!['tool','memory','note'].includes(m.kind));
      return {role,status:job.status==='running'&&member?.status==='working'?'working':work.length?'participated':'assigned',
        assignment:assignment?{id:assignment.id,seq:assignment.seq,text:snippet(assignment.text,220)}:null,
        tools:work.filter(m=>m.kind==='tool').length,latest:latest?{id:latest.id,seq:latest.seq,text:snippet(latest.text,200)}:null};
    }).filter(Boolean);
    const artifactIds=new Set(job.artifactIds??[]);
    for(const a of state.artifacts)if(a.jobId===job.id)artifactIds.add(a.id);
    for(const e of state.evidence)if(e.jobId===job.id){if(e.tool==='artifact_create')artifactIds.add(e.value.id);if(e.tool==='artifact_read')artifactIds.add(e.value.artifactId);}
    const artifacts=state.artifacts.filter(a=>artifactIds.has(a.id)).map(a=>({id:a.id,title:a.title,review:a.review?.verdict??'pending',replaces:a.replaces}));
    const decision=messages.findLast(m=>m.kind==='decision');
    const status=jobDisplayStatus(job,state.jobs);
    return {id:job.id,number:state.jobs.indexOf(job)+1,text:job.text,status,createdAt:job.createdAt,
      modelCalls:job.modelCalls??0,error:job.error??null,processCount:messages.length,toolCount:tools.length,assignments,artifacts,
      decision:decision?{id:decision.id,seq:decision.seq,text:snippet(decision.text,420)}:null,
      issues:jobIssues.slice(-8),openIssues:jobIssues.filter(i=>i.status==='open').length,attention:pending.has(status)};
  });
  return {jobs,issues:[...issues.filter(i=>i.status==='open').reverse(),...issues.filter(i=>i.status==='recovered').slice(-40).reverse()],openIssues:issues.filter(i=>i.status==='open').length,
    attentionJobs:state.jobs.filter(j=>pending.has(jobDisplayStatus(j,state.jobs))).length,messageCount:state.messages.length,
    running:state.jobs.find(j=>j.status==='running')?.id??null};
}
