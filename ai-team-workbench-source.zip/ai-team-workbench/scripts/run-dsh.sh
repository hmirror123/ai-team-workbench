#!/usr/bin/env bash
set -euo pipefail
umask 077

repo_dir=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd -P)
data_directory=${AI_TEAM_DATA:?AI_TEAM_DATA must be set by the workbench}
export DSH_HOME="$data_directory/dsh-home"

if [[ -z "${DEEPSEEK_API_KEY:-}" && -s "$data_directory/deepseek-api-key" ]]; then
  IFS= read -r DEEPSEEK_API_KEY < "$data_directory/deepseek-api-key" || true
fi

if [[ -z "${DEEPSEEK_API_KEY:-}" ]]; then
  printf '请在工作台主机配置 DeepSeek API Key。\n' >&2
  exit 1
fi

export DEEPSEEK_API_KEY
exec "${AI_TEAM_NODE:-node}" "$repo_dir/node_modules/@deepseek-ai/dsh/lib/bin.js" "$@"
