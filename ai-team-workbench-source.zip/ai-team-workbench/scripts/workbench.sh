#!/usr/bin/env bash
set -euo pipefail
umask 077

repo_dir=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd -P)
cd -- "$repo_dir"

fail() { printf '%s\n' "$1" >&2; exit 1; }

command -v node >/dev/null || fail '需要安装 Node.js 24.9 或更高版本。'
node --input-type=module -e 'const [major, minor] = process.versions.node.split(".").map(Number); process.exit(major > 24 || (major === 24 && minor >= 9) ? 0 : 1)' || fail '需要安装 Node.js 24.9 或更高版本。'
command -v timeout >/dev/null || fail '需要 Linux coreutils 中的 timeout 命令。'
[[ -f "$repo_dir/node_modules/@deepseek-ai/dsh/lib/bin.js" ]] || fail '请先运行 npm ci --ignore-scripts。'

data_directory=${AI_TEAM_DATA:-${XDG_DATA_HOME:-$HOME/.local/share}/ai-team-workbench}
[[ "$data_directory" = /* ]] || fail 'AI_TEAM_DATA 必须是绝对路径。'
AI_TEAM_DATA=$(realpath -m -- "$data_directory")
[[ "$AI_TEAM_DATA" != "$repo_dir" && "$AI_TEAM_DATA" != "$repo_dir/"* ]] || fail '请选择源码目录之外的 AI_TEAM_DATA，避免把运行数据提交到 Git。'
export AI_TEAM_DATA

config_path="$AI_TEAM_DATA/config.json"
key_path="$AI_TEAM_DATA/deepseek-api-key"
node_path=$(command -v node)

prepare() {
  mkdir -p -- "$AI_TEAM_DATA"
  if [[ ! -x "$repo_dir/scripts/run-dsh.sh" ]]; then
    chmod u+x -- "$repo_dir/scripts/run-dsh.sh"
  fi
  local password='' confirmation='' key='' temp_key=''
  if [[ ! -f "$config_path" ]]; then
    if [[ -n "${AI_TEAM_INSTALL_PASSWORD:-}" ]]; then
      password=$AI_TEAM_INSTALL_PASSWORD
      unset AI_TEAM_INSTALL_PASSWORD
    else
      [[ -t 0 ]] || fail '请在终端交互运行 npm run setup 来设置访问口令。'
      read -rs -p '设置工作台口令（至少 8 位）：' password
      printf '\n' >&2
      read -rs -p '再输入一次：' confirmation
      printf '\n' >&2
      [[ "$password" == "$confirmation" ]] || fail '两次输入不一致。'
    fi
  fi

  printf '%s' "$password" | "$node_path" app/setup.mjs "$AI_TEAM_DATA" "$repo_dir/scripts/run-dsh.sh"

  if [[ ! -s "$key_path" && -z "${DEEPSEEK_API_KEY:-}" ]]; then
    [[ -t 0 ]] || fail '请设置 DEEPSEEK_API_KEY，或在终端重新运行 npm run setup 输入密钥。'
    read -rs -p '输入自己的 DeepSeek API Key：' key
    printf '\n' >&2
    [[ -n "$key" && "$key" != *[[:space:]]* ]] || fail 'API Key 不能为空或包含空白。'
    temp_key=$(mktemp -- "$AI_TEAM_DATA/.deepseek-key.XXXXXXXX")
    printf '%s\n' "$key" > "$temp_key"
    mv -f -- "$temp_key" "$key_path"
    printf 'API Key 已保存到私有数据目录。\n'
  fi
  printf '配置完成。运行 npm start 打开工作台。\n'
}

check_config() {
  [[ -f "$config_path" ]] || fail '请先运行 npm run setup。'
}

install_service() {
  check_config
  [[ -s "$key_path" ]] || fail '常驻服务需要私有数据目录里的 API Key。请运行 env -u DEEPSEEK_API_KEY npm run setup 交互保存。'
  command -v systemctl >/dev/null || fail '此系统没有 systemd，可用 npm start 前台运行。'
  systemctl --user show-environment >/dev/null || fail '当前用户的 systemd 服务管理器不可用，可用 npm start 前台运行。'
  local unit_dir="${XDG_CONFIG_HOME:-$HOME/.config}/systemd/user"
  mkdir -p -- "$unit_dir"
  local unit="$unit_dir/ai-team-workbench.service"
  "$node_path" scripts/write-service.mjs "$node_path" "$repo_dir/app/server.mjs" "$AI_TEAM_DATA" "$unit"
  systemctl --user daemon-reload
  systemctl --user enable --now ai-team-workbench.service
  printf '常驻服务已启用。运行 systemctl --user status ai-team-workbench.service 查看状态。\n'
}

case ${1:-start} in
  setup) prepare ;;
  start)
    check_config
    [[ -n "${DEEPSEEK_API_KEY:-}" || -s "$key_path" ]] || fail '请先配置自己的 DeepSeek API Key。'
    exec "$node_path" app/server.mjs
    ;;
  service) install_service ;;
  *) fail '可用命令为 npm run setup、npm start、npm run service:install。' ;;
esac
