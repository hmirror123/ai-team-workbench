import fs from 'node:fs';
import {spawnSync} from 'node:child_process';
import path from 'node:path';

const [node, server, dataDirectory, unitFile] = process.argv.slice(2);
for (const value of [node, server, dataDirectory, unitFile]) {
  if (!value || !path.isAbsolute(value) || /[\r\n]/.test(value)) {
    throw new Error('服务需要有效的绝对路径。');
  }
}

const quote = value => JSON.stringify(value.replaceAll('%', '%%'));
const command = value => quote(value.replaceAll('$', '$$'));
const text = `[Unit]
Description=AI Team Workbench
After=network-online.target

[Service]
Type=simple
Environment=${quote('AI_TEAM_DATA=' + dataDirectory)}
ExecStart=${command(node)} ${command(server)}
Restart=on-failure
RestartSec=3
TimeoutStopSec=15
KillMode=control-group
UMask=0077

[Install]
WantedBy=default.target
`;

const staging = fs.mkdtempSync(path.join(path.dirname(unitFile), '.workbench-'));
const candidate = path.join(staging, path.basename(unitFile));
try {
  fs.writeFileSync(candidate, text, {mode: 0o600});
  const verification = spawnSync('systemd-analyze', ['verify', '--man=no', candidate], {stdio: 'inherit'});
  if (verification.error?.code !== 'ENOENT' && (verification.error || verification.status !== 0)) {
    throw new Error('服务文件验证失败。');
  }
  fs.renameSync(candidate, unitFile);
} finally {
  fs.rmSync(staging, {recursive: true, force: true});
}
