# AI Team Workbench · AI 团队工作台

在自己的电脑或服务器运行一个单用户网页工作台。总管、研究员、工程师、审核员各有持续会话和角色记忆，在同一个项目内公开交接。每轮任务保留实际工具结果、交付文件、审核结论和报错。项目之间独立保存。

协作引擎使用 [DeepSeek Harness](https://github.com/deepseek-ai/deepseek-harness)，锁定 `0.2.2-rc.4`。工作台为 Node.js 服务，含网页、任务队列、资料与产出管理以及 DSH 协作插件。

## 安装和启动

需要 Linux、Node.js 24.9 或更高版本、npm 和 GNU coreutils。下载或克隆本仓库后，在源码目录运行：

```bash
npm ci --ignore-scripts
npm run setup
npm start
```

首次配置会在终端隐藏输入，让你设置网页口令和自己的 DeepSeek API Key。默认访问 `http://127.0.0.1:3358`。如使用远程服务器，可从自己的设备开启 SSH 转发：

```bash
ssh -N -L 3358:127.0.0.1:3358 your-user@your-server
```

配置和运行数据默认放在 `~/.local/share/ai-team-workbench`。可用 `XDG_DATA_HOME` 或绝对路径 `AI_TEAM_DATA` 指定位置。口令以 scrypt 哈希保存。API Key 保存在私有数据文件中，模型进程按需读取。也可以通过 `DEEPSEEK_API_KEY` 环境变量提供，无需保存到文件。新目录会创建自己的 Harness 会话空间。

端口被占用时，用 `AI_TEAM_PORT=3359 npm run setup` 更新配置，再启动服务。上传资料和报告都保存在数据目录中，Git 只跟踪源码。

## 复现一次正式审核

在网页中新建项目，上传 [review-sample.csv](examples/review-sample.csv)，发送下面的指令：

> 请工程师保存一份待审核报告，暂以「T2 平均值 48，所有记录均有日期」作为待检查结论。让审核员实际读取报告和 CSV，独立计算 T2 平均值并检查日期。有误就公开给出证据并登记要求修改，让工程师另存修订版，最后审核员读取新版并登记审核。

示例为人工合成数据。T2 平均值应为 **44**，`S03` 的日期为空。可在任务梳理中打开两版报告，核对是谁计算、谁要求修改以及最终审核的是哪一版。各模型实际完成流程的表现可能不同。

已验证的资料格式为 TXT、Markdown、CSV、TSV、JSON 和 LOG，单个文件最多 8 MB。工作台采用只读资料工具，产出另存。当前任务全局并发为 1，单轮五分钟。定时联网检索和飞书提醒需要另接自动化，首次安装只提供手动发起任务。

## 不使用 API Key 的验证

```bash
npm test
npm run test:native
npm run test:ui
```

- `npm test` 检查 HTTP 登录、队列、项目隔离、报告与正式审核，以及任务续接。
- `npm run test:native` 使用实际 Harness 和本地模拟模型，验证两个项目各自建立和续接独立成员、执行工具、保存产出、登记审核及请求串行。
- `npm run test:ui` 在模拟浏览器 DOM 中检查任务梳理、报错展示、切换项目、上传和审核续接。

## 在服务器上常驻

首次配置时将模型密钥保存在私有数据目录。结束前台 `npm start`，然后运行：

```bash
npm run service:install
systemctl --user status ai-team-workbench.service
```

该命令需要可用的 systemd 用户服务管理器。让服务在退出 SSH 后或开机时持续运行，取决于服务器的用户驻留设置，可用 `loginctl show-user "$USER" -p Linger` 查询。查看日志可用 `journalctl --user -u ai-team-workbench.service -n 40`。

## 代码结构

| 位置 | 用途 |
|---|---|
| `app/public/` | 项目切换、任务梳理与群聊网页 |
| `app/server.mjs` | 登录、任务执行和进度 API |
| `app/team-plugin.mjs` | 独立成员、公开交接与受限工具 |
| `app/core.mjs`、`app/projects.mjs` | 数据、记忆、分项目存储与正式审核 |
| `scripts/` | 终端配置、启动和 systemd 服务 |

工作台源码使用 MIT 许可证。DeepSeek Harness 由 npm 单独安装，适用其自身许可证。模型调用和服务器按各自服务商规则计费。
